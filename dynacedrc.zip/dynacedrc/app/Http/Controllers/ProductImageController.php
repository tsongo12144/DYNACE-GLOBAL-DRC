<?php

namespace App\Http\Controllers;
use App\Http\Requests\ProductImageRequest; 
use App\Models\Product; 
use App\Models\ProductImage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;


class ProductImageController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $productImages = ProductImage::all(); 
        return view('admin.productImage.index', compact('productImages'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $productImage=new Product();
        $products= Product::pluck('name', 'id'); 
        return view('admin.productImage.create', compact('products','productImage'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(ProductImageRequest $request)
    {
    //productImage new
    $data = $request->validated();
    if ($request->hasFile('image')){
    $file = $request->file('image');
    $filename = $file->getClientOriginalName();
    $path = $file->storeAs('productImages', $filename, 'public');
    $data['image'] = 'productImages/' . $filename;
    }  
    ProductImage::create($data);
    return redirect()->route('product-images.index')->with('success', 'Created Successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(ProductImage $productImage)
    {
    return view('admin.productImage.show', compact('productImage'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(ProductImage $productImage)
    {
        $products=new Product();
        return view('admin.productImage.edit', compact('productImage','products'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(ProductImageRequest $request, ProductImage $productImage)
    {
        $data = $request->validated();
        if ($request->hasFile('image')) {
            Storage::disk('public')->delete($productImage->image);
            $file = $request->file('image'); 
            $filename = $file->getClientOriginalName(); 
            $path = $file->storeAs('productImages', $filename, 'public'); // Store the image publicly in the 'pro' folder 
            $data['image'] = 'productImages/' . $filename;
            }
            $data['product_id'] = $productImage->product_id;
            $productImage->update($data); 
            return redirect()->route('product-images.index')->with('success', 'Updated Success');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(ProductImage $productImage)
    {
        // Delete the image from storage 
        Storage::disk('public')->delete($productImage->image);
        // Delete the productImage record from the database
         $productImage->delete();
         return redirect()->route('product-images.index')->with('success', 'Deleted Successfully.');
    }
}
