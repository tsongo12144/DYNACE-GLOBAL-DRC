<?php

namespace App\Http\Controllers;
use App\Http\Requests\IngredientRequest; 
use App\Models\Product; 
use App\Models\Ingredient; 
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class IngredientController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $ingredients = Ingredient::all(); 
        return view('admin.ingredient.index', compact('ingredients'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $ingredient=new Ingredient();
        $products= Product::pluck('name', 'id'); 
        return view('admin.ingredient.create', compact('products','ingredient'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(IngredientRequest $request)
    {
    //reviews new
    $data = $request->validated();
    if ($request->hasFile('image')){
    $file = $request->file('image');
    $filename = $file->getClientOriginalName();
    $path = $file->storeAs('ingredients', $filename, 'public');
    $data['image'] = 'ingredients/' . $filename;
    }  
    Ingredient::create($data);
    return redirect()->route('ingredients.index')->with('success', 'Created Successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Ingredient $ingredient)
    {
    return view('admin.ingredient.show', compact('ingredient'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Ingredient $ingredient)
    {
        $products=new Product();
        return view('admin.ingredient.edit', compact('ingredient','products'));

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(IngredientRequest $request, Ingredient $ingredient)
    {
    $data = $request->validated();
    if ($request->hasFile('image')) {
        Storage::disk('public')->delete($ingredient->image);
        $file = $request->file('image'); 
        $filename = $file->getClientOriginalName(); 
        $path = $file->storeAs('ingredients', $filename, 'public'); // Store the image publicly in the 'pro' folder 
        $data['image'] = 'ingredients/' . $filename;
        }
    $data['product_id'] = $ingredient->product_id;
    $ingredient->update($data); 
    return redirect()->route('ingredients.index')->with('success', 'Updated Success');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Ingredient $ingredient)
    {
    Storage::disk('public')->delete($ingredient->image);
    $ingredient->delete();
    return redirect()->route('ingredients.index')->with('success', 'Deleted Successfully.');
    }
}
