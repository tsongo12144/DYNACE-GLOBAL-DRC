<?php

namespace App\Http\Controllers;
use App\Models\Banner;
use Illuminate\Http\Request;
use App\Http\Requests\BannerRequest;
use Illuminate\Support\Facades\Storage;


class BannerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $banners = Banner::all(); 
        return view('admin.banner.index', compact('banners'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('admin.banner.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(BannerRequest $request)
    {
    //banner new
    $data = $request->validated();
    if ($request->hasFile('photo')){
    $file = $request->file('photo');
    $filename = $file->getClientOriginalName();
    $path = $file->storeAs('banners', $filename, 'public');
    $data['photo'] = 'banners/' . $filename;
    }  
    Banner::create($data);
    return redirect()->route('banners.index')->with('success', 'Created Successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Banner $banner)
    {
        //
    return view('admin.banner.show', compact('banner'));

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Banner $banner)
    {
        return view('admin.banner.edit', compact('banner'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(BannerRequest $request, Banner $banner)
    {
    $data = $request->validated();
    if ($request->hasFile('photo')) {
    // Delete the old photo 
    Storage::disk('public')->delete($banner->photo);
    // Upload the new photo 
    $file = $request->file('photo'); 
    $filename = $file->getClientOriginalName(); 
    $path = $file->storeAs('banners', $filename, 'public'); // Store the photo publicly in the 'banners' folder 
    $data['photo'] = 'banners/' . $filename;
    }
    $banner->update($data); 
    return redirect()->route('banners.index')->with('success', 'Updated Success');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Banner $banner)
    {
                // Delete the image from storage 
                Storage::disk('public')->delete($banner->photo);
                // Delete the banner record from the database
                 $banner->delete();
                 return redirect()->route('banners.index')->with('success', 'Deleted Successfully.');
    }
}
