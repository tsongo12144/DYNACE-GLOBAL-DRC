<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\ProductRequest;
use App\Models\Product;
use Illuminate\Support\Facades\Storage;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

              $products = Product::all(); 
              return view('admin.product.index', compact('products'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('admin.product.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(ProductRequest $request)
    {
    //banner new
    $data = $request->validated();
    if ($request->hasFile('cover_photo')){
    $file = $request->file('cover_photo');
    $filename = $file->getClientOriginalName();
    $path = $file->storeAs('covers', $filename, 'public');
    $data['cover_photo'] = 'covers/' . $filename;
    }  
    Product::create($data);
    return redirect()->route('products.index')->with('success', 'Created Successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Product $product)
    {
    return view('admin.product.show', compact('product'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Product $product)
    {
        //
        return view('admin.product.edit', compact('product'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(ProductRequest $request,Product $product)
    {
        $data = $request->validated();
        if ($request->hasFile('cover_photo')) {
        // Delete the old cover_photo 
        Storage::disk('public')->delete($product->cover_photo);
        // Upload the new cover_photo 
        $file = $request->file('cover_photo'); 
        $filename = $file->getClientOriginalName(); 
        $path = $file->storeAs('covers', $filename, 'public'); // Store the cover_photo publicly in the 'covers' folder 
        $data['cover_photo'] = 'covers/' . $filename;
        }
        $product->update($data); 
        return redirect()->route('products.index')->with('success', 'Updated Success');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Product $product)
    {
         Storage::disk('public')->delete($product->cover_photo);
          $product->delete();
          return redirect()->route('products.index')->with('success', 'Deleted Successfully.');
    }
}
