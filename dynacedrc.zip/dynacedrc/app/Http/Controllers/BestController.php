<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Requests\BestRequest;
use Illuminate\Support\Facades\Storage;
use App\Models\Best;

class BestController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
                $bests = Best::all(); 
                return view('admin.best.index', compact('bests'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.best.create');
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(BestRequest $request)
    {
      //banner new
    $data = $request->validated();
    if ($request->hasFile('photo')){
    $file = $request->file('photo');
    $filename = $file->getClientOriginalName();
    $path = $file->storeAs('bests', $filename, 'public');
    $data['photo'] = 'bests/' . $filename;
    }  
    Best::create($data);
    return redirect()->route('best.index')->with('success', 'Created Successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Best $best)
    {
    return view('admin.best.show',compact('best'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Best $best){
    return view('admin.best.edit', compact('best'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(BestRequest $request,Best $best)
    {
        $data = $request->validated();
        if ($request->hasFile('photo')) {
        // Delete the old photo 
        Storage::disk('public')->delete($best->photo);
        // Upload the new photo 
        $file = $request->file('photo'); 
        $filename = $file->getClientOriginalName(); 
        $path = $file->storeAs('bests', $filename, 'public'); // Store the photo publicly in the 'bests' folder 
        $data['photo'] = 'bests/' . $filename;
        }
        $best->update($data); 
        return redirect()->route('best.index')->with('success', 'Updated Success');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Best $best)
    {
        // Delete the image from storage 
        Storage::disk('public')->delete($best->photo);
        // Delete the banner record from the database
         $best->delete();
         return redirect()->route('best.index')->with('success', 'Deleted Successfully.');
    }
}
