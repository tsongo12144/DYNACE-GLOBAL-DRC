<?php

namespace App\Http\Controllers;
use App\Http\Requests\PricingRequest; 
use App\Models\Product; 
use App\Models\Pricing; 
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class PricingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $pricings = Pricing::all(); 
        return view('admin.pricing.index', compact('pricings'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $pricings=new Pricing();
        $products= Product::pluck('name', 'id'); 
        return view('admin.pricing.create', compact('products','pricings'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(PricingRequest $request)
    {
    //pricings new
    $data = $request->validated();
    Pricing::create($data);
    return redirect()->route('pricings.index')->with('success', 'Created Successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Pricing $pricing)
    {
    return view('admin.pricing.show', compact('pricing'));
        
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Pricing $pricing)
    {
        $products=new Product();
        return view('admin.pricing.edit', compact('pricing','products'));

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(PricingRequest $request, Pricing $pricing)
    {
    $data = $request->validated();
    $data['product_id'] = $pricing->product_id;
    $pricing->update($data); 
    return redirect()->route('pricings.index')->with('success', 'Updated Success');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Pricing $pricing)
    {
          $pricing->delete();
          return redirect()->route('pricings.index')->with('success', 'Deleted Successfully.');
    }
}
