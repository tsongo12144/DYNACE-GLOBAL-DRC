<?php

namespace App\Http\Controllers;
use App\Models\Post;
use Illuminate\Http\Request;
use App\Http\Requests\PostRequest;
use Illuminate\Support\Facades\Storage;


class PostController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $posts = Post::all(); 
        return view('admin.post.index', compact('posts'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('admin.post.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(PostRequest $request)
    {
    //Post new
    $data = $request->validated();
    if ($request->hasFile('image')){
    $file = $request->file('image');
    $filename = $file->getClientOriginalName();
    $path = $file->storeAs('posts', $filename, 'public');
    $data['image'] = 'posts/' . $filename;
    }  
    Post::create($data);
    return redirect()->route('posts.index')->with('success', 'Created Successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Post $post)
    {
        //
    return view('admin.post.show', compact('post'));

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Post $post)
    {
        return view('admin.post.edit', compact('post'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(PostRequest $request, Post $post)
    {
    $data = $request->validated();
    if ($request->hasFile('image')) {
    // Delete the old image 
    Storage::disk('public')->delete($post->image);
    // Upload the new image 
    $file = $request->file('image'); 
    $filename = $file->getClientOriginalName(); 
    $path = $file->storeAs('posts', $filename, 'public'); // Store the image publicly in the 'posts' folder 
    $data['image'] = 'posts/' . $filename;
    }
    $post->update($data); 
    return redirect()->route('posts.index')->with('success', 'Updated Success');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Post $post)
    {
                // Delete the image from storage 
                Storage::disk('public')->delete($post->image);
                // Delete the banner record from the database
                 $post->delete();
                 return redirect()->route('posts.index')->with('success', 'Deleted Successfully.');
    }
}
