<?php

namespace App\Http\Controllers;
use App\Http\Requests\RecommendationRequest; 
use App\Models\Product; 
use App\Models\Recommendation; 
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class RecommendationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $recommendations = Recommendation::all(); 
        return view('admin.reco.index', compact('recommendations'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $recommendation=new Recommendation();
        $products= Product::pluck('name', 'id'); 
        return view('admin.reco.create', compact('products','recommendation'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(RecommendationRequest $request)
    {
    //reviews new
    $data = $request->validated();
    if ($request->hasFile('image')){
    $file = $request->file('image');
    $filename = $file->getClientOriginalName();
    $path = $file->storeAs('recos', $filename, 'public');
    $data['image'] = 'recos/' . $filename;
    }  
    Recommendation::create($data);
    return redirect()->route('recommendations.index')->with('success', 'Created Successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Recommendation $recommendation)
    {
    return view('admin.reco.show', compact('recommendation'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Recommendation $recommendation)
    {
        $products=new Product();
        return view('admin.reco.edit', compact('recommendation','products'));

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(RecommendationRequest $request, Recommendation $recommendation)
    {
    $data = $request->validated();
    if ($request->hasFile('image')) {
        Storage::disk('public')->delete($recommendation->image);
        $file = $request->file('image'); 
        $filename = $file->getClientOriginalName(); 
        $path = $file->storeAs('recos', $filename, 'public'); // Store the image publicly in the 'pro' folder 
        $data['image'] = 'recos/' . $filename;
        }
    $data['product_id'] = $recommendation->product_id;
    $recommendation->update($data); 
    return redirect()->route('recommendations.index')->with('success', 'Updated Success');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Recommendation $recommendation)
    {
    Storage::disk('public')->delete($recommendation->image);
    $recommendation->delete();
    return redirect()->route('recommendations.index')->with('success', 'Deleted Successfully.');
    }
}
