<?php

namespace App\Http\Controllers;
use App\Models\Banner;
use App\Models\Best;
use App\Models\Gallery;
use App\Models\Member;
use App\Models\Team;
use App\Models\Product;
use App\Models\Real;
use App\Models\Post;

use Illuminate\Http\Request;

class AdminController extends Controller
{
    //
    public function admin(){
    $banners=Banner::all();
    $bests=Best::all();
    $teams=Team::all();
    $galleries=Gallery::all();
    $products=Product::all();
    $reals=Real::all();
    $posts=Post::all();
    $members=Member::all();
    return view('admin.index',compact('banners','bests','galleries','teams','products','reals','posts','members'));
    }
}
