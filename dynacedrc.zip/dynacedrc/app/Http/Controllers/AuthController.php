<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth; 
use App\Models\Admin;

class AuthController extends Controller
{
    public function showLoginForm() { 
        return view('admin.auth.login'); 
    }

        public function login(Request $request) { 
        $request->validate(
            [ 'username' => 'required', 
            'password' => 'required', ], 
            [ 
                'username.required' => 'Le nom d\'utilisateur est obligatoire.', 
            'password.required' => 'Le mot de passe est obligatoire.', ]); 
            $admin = Admin::where('username', $request->username) ->where('password', sha1($request->password)) ->count();

            if ($admin) { 
            $adminData = Admin::where('username', $request->username) ->where('password', sha1($request->password)) ->first();
            session(['adminData' => $adminData]);
            return redirect()->route('adminPannel')->with('logsuccess', 'Connexion réussie.'); 
            } 
            else
            { 
            return back()->with(['success' => 'Nom d\'utilisateur ou mot de passe incorrect.']); }
            }
            public function logout() {
            Auth::logout(); 
            session()->forget(['adminData']);
            return redirect()->route('login')->with('success', 'Déconnexion réussie.'); 
            }
            public function showChangePasswordForm() {
            return view('admin.auth.change_password'); 
            }

        public function changePassword(Request $request) { 

            $request->validate([ 
                'username' => 'max:255', 
                'old_password' => 'required',
                 'new_password' => 'required',
                 'confirmed',
                'string', 
                'min:8', 
                'regex:/[a-z]/', // must contain at least one lowercase letter 
                'regex:/[A-Z]/', // must contain at least one uppercase letter 
                'regex:/[0-9]/', // must contain at least one digit 
                'regex:/[@$!%*#?&]/', // must contain a special character 
                'confirmed',               
                ],
            [ 
                'username.required' => 'Le nom d\'utilisateur est obligatoire.', 
                'username.string' => 'Le nom d\'utilisateur doit être une chaîne de caractères.', 
                'username.max' => 'Le nom d\'utilisateur ne doit pas dépasser 255 caractères.', 
                'old_password.required' => 'L\'ancien mot de passe est obligatoire.',
                'new_password.required' => 'Le nouveau mot de passe est obligatoire.', 
                'new_password.regex' => 'Le nouveau mot de passe doit contenir au moins une lettre majuscule, une lettre minuscule, un chiffre et un caractère spécial.',
                'new_password.confirmed' => 'La confirmation du mot de passe ne correspond pas.', ]);      
                
                $admin = session('adminData'); // Retrieve the admin data from the session 
                if ($admin->password !== sha1($request->old_password)) { 
                return back()->with(['success' => 'L\'ancien mot de passe est incorrect.']);
                }

            $admin->username = $request->username; 
            $admin->password = sha1($request->new_password); 
            $admin->save();
            // Update session data 
            session(['adminData' => $admin]);
            return redirect()->route('adminPannel')->with('logsuccess', 'Nom d\'utilisateur et mot de passe modifiés avec succès.');
        }

}
