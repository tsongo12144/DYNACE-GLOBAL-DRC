<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Banner;
use App\Models\Product;
use App\Models\Team;
use App\Models\Best;
use App\Models\Real;
use App\Models\Gallery;
use App\Models\Post;

class HomeController extends Controller
{
    //
    public function index(){
    $banners = Banner::where('status','Actif')->get();
    $teams = Team::get();
    $bestItems = Best::get();
    $products = Product::get();
    $reals = Real::get();
    $galleries = Gallery::get();
    $posts = Post::get();
    return view('client.index',compact('banners','teams','bestItems','products','reals','galleries','posts'));
    }
    public function showTeam(Team $team){
    return view('client.team',compact('team'));     
    }

    public function showProduct(Product $product){
    return view('client.product',compact('product'));    
    }

}
