<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class MemberRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'first_name' => 'required|string|max:255',
             'last_name' => 'required|string|max:255',
              'phone' => 'required|string|max:20', 
              'email' => 'nullable|email|max:255|email' ,
        ];
    }

    public function messages() { 
        return [ 
            'first_name.required' => 'Le prénom est obligatoire.', 
            'last_name.required' => 'Le nom de famille est obligatoire.', 
            'phone.required' => 'Le téléphone est obligatoire.', 
            'email.required' => 'L\'adresse e-mail est obligatoire.', 
            'email.email' => 'L\'adresse e-mail doit être une adresse e-mail valide.',
             'email.unique' => 'Cette adresse e-mail est déjà enregistrée.', ]; 
            }
}
