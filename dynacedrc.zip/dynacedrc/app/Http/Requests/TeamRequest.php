<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class TeamRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [ 
            'name' => 'required|max:30', 
            'profile' => 'nullable|image|max:8096|mimes:jpeg,jpg,png',
            'team_picture' => 'nullable|image|max:8096|mimes:jpeg,jpg,png',
            'description' => 'nullable',
            'description_add' => 'nullable',
            'team_name' => 'nullable',
            'role' => 'required|max:50',
           ];
    }

    public function messages() { 
        return [ 
            'name.required' => 'Le nom est obligatoire.', 
            'name.max' => 'Le nom ne doit pas dépasser 30 caractères.', 

            'role.required' => 'Le role(s) est obligatoire.', 
            'role.max' => 'Le le role(s) ne doit pas dépasser 30 caractères.', 

            'profile.required' => 'Le profile est obligatoire.', 
            'profile.image' => 'Le fichier doit être une image.', 
            'profile.max' => 'La taille de l\'image ne doit pas dépasser 4MB.', 
            'profile.mimes' => 'L\'image doit être au format jpeg, jpg ou png.', 

            'team_picture.required' => 'Le team_picture est obligatoire.', 
            'team_picture.image' => 'Le fichier doit être une image.', 
            'team_picture.max' => 'La taille de l\'image ne doit pas dépasser 4MB.', 
            'team_picture.mimes' => 'L\'image doit être au format jpeg, jpg ou png.', 
            
        ]; 
    }

}
