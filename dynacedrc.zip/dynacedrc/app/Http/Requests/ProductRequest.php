<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ProductRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name' => 'required|string|max:255', 
            'cover_photo' =>'nullable|image|max:4096|mimes:jpeg,jpg,png',
            'description' => 'required|string',
            'prescription' => 'required|string',
            'status' => 'nullable|string',
        ];
    }

    public function messages() { return [ 
        'name.required' => 'Le nom est obligatoire.', 
        'name.string' => 'Le nom doit être une chaîne de caractères.',
        'name.max' => 'Le nom ne peut pas dépasser 255 caractères.', 
        'cover_photo.required' => 'La photo de couverture est obligatoire.', 
        'cover_photo.string' => 'La photo de couverture doit être une chaîne de caractères.', 
        'cover_photo.max' => 'La photo de couverture ne peut pas dépasser 255 caractères.', 
        'description.required' => 'La description est obligatoire.', 
        'description.string' => 'La description doit être une chaîne de caractères.',
         'prescription.required' => 'La prescription est obligatoire.',
          'prescription.string' => 'La prescription doit être une chaîne de caractères.', 
        ];
        }
}
