<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class BannerRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [ 
                    'title' => 'required|max:30', 
                    'photo' => 'nullable|image|max:4096|mimes:jpeg,jpg,png',
                    'status' => 'required',
                   ];
    }

    public function messages() { 
        return [ 
            'title.required' => 'Le titre est obligatoire.', 
            'title.max' => 'Le titre ne doit pas dépasser 30 caractères.', 
            'photo.required' => 'La photo est obligatoire.', 
            'photo.image' => 'Le fichier doit être une image.', 
            'photo.max' => 'La taille de l\'image ne doit pas dépasser 4MB.', 
            'photo.mimes' => 'L\'image doit être au format jpeg, jpg ou png.', 
            'status.required' => 'Le statut est obligatoire.'
        ]; 
    }
    }
