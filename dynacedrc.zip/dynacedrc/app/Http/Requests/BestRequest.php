<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class BestRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [ 
        'name' => 'required|string|max:255',
        'description' => 'nullable', 
        'status' => 'nullable', 
        'photo' => 'image|max:4096|mimes:jpeg,jpg,png', ];
    }

    public function messages() {
         return [ 
        'name.required' => 'Le nom est obligatoire.',
         'description.required' => 'La description est obligatoire.', 
         'status.required' => 'Le statut est obligatoire.', 
         'photo.required' => 'La photo est obligatoire.',
         'photo.image' => 'Le fichier doit être une image.', 
         'photo.max' => 'La taille de l\'image ne doit pas dépasser 4MB.', 
         'photo.mimes' => 'L\'image doit être au format jpeg, jpg ou png.', ]; 
        }
}
