<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Real extends Model
{
    use HasFactory;

    protected $fillable=[
    'date',
    'desc1',
    'desc2',
    'image',
    ];
}
