<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class team extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'profile',
        'description',
        'role',
        'team_picture',
        'team_name',
        'description_add'
    ];
}
