<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    protected $fillable = ['name', 'cover_photo', 'description', 'prescription','status'];

    public function productImages()
    {
    return $this->hasMany(ProductImage::class);
    }

    public function causes()
    {
    return $this->hasMany(Cause::class);
    }

    public function ingredients()
    {
    return $this->hasMany(Ingredient::class);
    }

    public function recommendations()
    {
    return $this->hasMany(Recommendation::class);
    }

    public function pricings()
    {
    return $this->hasMany(Pricing::class);
    }

    public function reviews()
    {
    return $this->hasMany(Review::class);
    }

    }

