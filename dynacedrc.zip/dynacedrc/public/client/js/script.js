
document.addEventListener('DOMContentLoaded', (event) => {
    const sections = document.querySelectorAll('section');
    const options = {
    threshold: 0.5
    };
    
    const observer = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
    if (entry.isIntersecting) {
    entry.target.style.animation = 'fadeInOnScroll 1s forwards';
    observer.unobserve(entry.target);
    }
    });
    }, options);
    
    sections.forEach(section => {
    observer.observe(section);
    });
    });
    
    
    
    
    // video modal
    document.addEventListener('DOMContentLoaded', (event) => {
    const aProposSection = document.querySelector('.a-propos');
    const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
    if (entry.isIntersecting) {
    entry.target.style.animation = 'fadeIn 1s forwards';
    observer.unobserve(entry.target);
    }
    });
    }, { threshold: 0.1 });
    
    observer.observe(aProposSection);
    
    
    });
    
    
    document.addEventListener('DOMContentLoaded', (event) => {
    const notreEquipeSection = document.querySelector('.notre-equipe');
    const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
    if (entry.isIntersecting) {
    entry.target.style.animation = 'fadeIn 1s forwards';
    observer.unobserve(entry.target);
    }
    });
    }, { threshold: 0.1 });
    
    observer.observe(notreEquipeSection);
    });
    
    
    document.addEventListener('DOMContentLoaded', (event) => {
    const nosServicesSection = document.querySelector('.nos-services');
    const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
    if (entry.isIntersecting) {
    entry.target.style.animation = 'fadeIn 1s forwards';
    observer.unobserve(entry.target);
    }
    });
    }, { threshold: 0.1 });
    
    observer.observe(nosServicesSection);
    });
    
    
    // our best
    document.addEventListener('DOMContentLoaded', (event) => {
    const swiper = new Swiper('.swiper-container', {
    loop: true,
    autoplay: {
    delay: 4000,
    disableOnInteraction: false,
    },
    slidesPerView: 'auto',
    centeredSlides: true,
    spaceBetween: 20,
    });
    });
    
    // our best
    
    
    // produits
    document.addEventListener('DOMContentLoaded', (event) => {
    const nosProduitsSection = document.querySelector('.nos-produits');
    const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
    if (entry.isIntersecting) {
    entry.target.style.animation = 'fadeInUp 0.5s ease-in-out forwards';
    observer.unobserve(entry.target);
    }
    });
    }, { threshold: 0.1 });
    
    observer.observe(nosProduitsSection);
    });
    
    // produits
    
    // realisations
    document.addEventListener('DOMContentLoaded', (event) => {
    const realisationsSection = document.querySelector('.realisations');
    const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
    if (entry.isIntersecting) {
    entry.target.style.animation = 'fadeIn 1s forwards';
    observer.unobserve(entry.target);
    }
    });
    }, { threshold: 0.1 });
    
    observer.observe(realisationsSection);
    
    const zoomIcons = document.querySelectorAll('.zoom-icon');
    zoomIcons.forEach(icon => {
    icon.addEventListener('click', (event) => {
    const imgSrc = icon.previousElementSibling.src;
    document.getElementById('zoomedImage').src = imgSrc;
    const zoomModal = new bootstrap.Modal(document.getElementById('zoomModal'));
    zoomModal.show();
    });
    });
    });
    
    // realisations


    document.addEventListener('DOMContentLoaded', (event) => {
        const causesSection = document.querySelector('.causes');
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.animation = 'fadeIn 1s forwards';
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.1 });
    
        observer.observe(causesSection);
    });

    
    
    
    