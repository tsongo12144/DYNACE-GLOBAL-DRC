<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\BannerController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\TeamController;
use App\Http\Controllers\BestController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\ProductImageController;
use App\Http\Controllers\ReviewController;
use App\Http\Controllers\PricingController;
use App\Http\Controllers\CauseController;
use App\Http\Controllers\IngredientController;
use App\Http\Controllers\RecommendationController;
use App\Http\Controllers\RealController;
use App\Http\Controllers\PostController;
use App\Http\Controllers\GalleryController;
use App\Http\Controllers\MemberController;
use App\Http\Controllers\AuthController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/',[HomeController::class,'index'])->name('client');

Route::get('/admin_pannel', [AdminController::class, 'admin'])->name('adminPannel');


Route::get('login', [AuthController::class, 'showLoginForm'])->name('login'); 
Route::post('login', [AuthController::class, 'login']); 
Route::post('logout', [AuthController::class, 'logout'])->name('logout');

Route::get('change-password', [AuthController::class, 'showChangePasswordForm'])->name('change-password'); 
Route::post('change-password', [AuthController::class, 'changePassword']);

// Route::middleware('auth')->group(function () { 
// Route::get('admin_pannel', function () {
// return view('admin.index'); 
// })->name('adminPannel'); 
// });

Route::get('team/{team}', [HomeController::class, 'showTeam'])->name('home.showTeam');
Route::get('product/{product}', [HomeController::class, 'showProduct'])->name('home.showProduct');


Route::get('storage-link',function(){
$targetFolder = storage_path('app/public');
$linkFolder = $_SERVER['DOCUMENT_ROOT'] . '/storage';
symlink($targetFolder,$linkFolder);
echo 'Symlink created successfully!';
});
   
//banners
Route::resource('banners', BannerController::class);
Route::resource('teams', TeamController::class);
Route::resource('best', BestController::class);
Route::resource('products', ProductController::class);
Route::resource('product-images', ProductImageController::class);
Route::resource('causes', CauseController::class);
Route::resource('pricings', PricingController::class);
Route::resource('ingredients', IngredientController::class);
Route::resource('reviews', ReviewController::class);
Route::resource('recommendations', RecommendationController::class);
Route::resource('reals', RealController::class);
Route::resource('posts', PostController::class);
Route::resource('galleries', GalleryController::class);
Route::resource('members', MemberController::class);







