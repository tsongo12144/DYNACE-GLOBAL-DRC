<form action="<?php echo e($action); ?>" method="POST" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
              <?php if($method === 'PUT'): ?> 
              <?php echo method_field('PUT'); ?> 
              <?php endif; ?>

            <!-- Row start -->
            <div class="row gutters">

            <div class="col-sm-12">
            <div class="card">
            <div class="card-body">

            <div class="row gutters">


          <div class="col-sm-4 col-12">
            <div class="form-group">
            <label for="inputName">Date</label>
            <input type="date" name="date"  id="date" value="<?php echo e(old('date',$real->date ?? '')); ?>" placeholder="Entrez Le Nom"
            class="form-control <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php else: ?> is-valid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  >
            <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback">
            <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>          
            </div>
            </div>

            

            <div class="col-sm-4 col-12">
              <div class="form-group">
              <label for="inputName">Photo</label>
              <input type="file" name="image"  id="image"  accept="image/*" 
              class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php else: ?> is-valid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  >
              <?php if(isset($real) && $real->image): ?> 
              <img src="<?php echo e(asset('storage/' . $real->image)); ?>" alt="image" width="100" class="mt-2"> 
              <?php endif; ?>
              <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="invalid-feedback">
              <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>          
              </div>
              </div>

            <div class="col-sm-4 col-12">
              <div class="form-group">
              <label for="inputName">Description 1</label>
              <textarea  rows="10" cols="10"   id="desc1" name="desc1" class="form-control <?php $__errorArgs = ['desc1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php else: ?> is-valid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <?php echo e(old('desc1', $real->desc1 ?? '')); ?>

              </textarea> 
              <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="invalid-feedback">
              <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>          
              </div>
              </div>

              <div class="col-sm-4 col-12">
                <div class="form-group">
                <label for="inputName">Description 2</label>
                <textarea  rows="10" cols="10"   id="desc2" name="desc2" class="form-control <?php $__errorArgs = ['desc2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php else: ?> is-valid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                  <?php echo e(old('desc2', $real->desc2 ?? '')); ?>

                </textarea> 
                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>          
                </div>
                </div>




            </div>
            <button type="submit" class="btn btn-primary mb-2"><?php echo e($buttonText); ?></button>
            </div>
              </div>
              </div>
              </div>
              <!-- Row end -->
</form><?php /**PATH C:\Users\user\Documents\laravel\dynacedrc\resources\views/admin/real/_form.blade.php ENDPATH**/ ?>