

<?php $__env->startSection('title'); ?>
banner
<?php $__env->stopSection(); ?>

        <?php $__env->startSection('bcontent'); ?>
        <div class="container">
        <a href="<?php echo e(route('banners.index')); ?>" class="btn btn-warning mb-2">Annuler</a>
        </div>
        <?php $__env->stopSection(); ?>

        <?php $__env->startSection('content'); ?> 
        <div class="container"> 
        <?php echo $__env->make('admin.banner._form', 
        [ 'action' => route('banners.store'),
        'method' => 'POST', 
        'buttonText' => 'Save', ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
        </div> 
        <?php $__env->stopSection(); ?>

        <?php $__env->startSection('scripts'); ?>

        <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\laravel\dynacedrc\resources\views/admin/banner/create.blade.php ENDPATH**/ ?>