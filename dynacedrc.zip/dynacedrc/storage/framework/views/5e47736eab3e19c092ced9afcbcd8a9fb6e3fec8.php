    <!doctype html>
    <html lang="en">

    <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Meta -->
    <meta name="description" content="Responsive Bootstrap Admin Dashboards">
    <meta name="author" content="Bootstrap Gallery">
    <link rel="shortcut icon" href="<?php echo e(asset('admin/img/logo.png')); ?>" />

    <!-- Title -->
    <title>
        <?php echo $__env->yieldContent('title'); ?>
    </title>

    <?php if(!Session::has('adminData')): ?>
    <script type="text/javascript">
    window.location.href = "<?php echo e(route('login')); ?>";
    </script>
    <?php endif; ?>      


    <!-- *************
    ************ Common Css Files *************
    ************ -->
    <!-- Bootstrap css -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/bootstrap.min.css')); ?>">
    <!-- Icomoon Font Icons css -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/fonts/style.css')); ?>">
    <!-- Main css -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/main.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('admin/css/admin.css')); ?>">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Figtree:ital,wght@0,300..900;1,300..900&family=Montserrat:ital,wght@0,100..900;1,100..900&family=Rubik:ital,wght@0,300..900;1,300..900&display=swap" rel="stylesheet">

    <!-- *************
    ************ Vendor Css Files *************
    ************ -->

    </head>

    <body>

    <!-- Loading starts -->
    <div id="loading-wrapper">
    <div class="spinner-border" role="status">
    <span class="sr-only">Loading...</span>
    </div>
    </div>
    <!-- Loading ends -->

    <!-- Page wrapper start -->
    <div class="page-wrapper">

    <!-- Sidebar wrapper start -->
    <nav id="sidebar" class="sidebar-wrapper">

    <!-- Sidebar brand start  -->
    <div class="sidebar-brand">
    <a href="index.html" class="logo">
    <img src="<?php echo e(asset('admin/img/logo.png')); ?>" alt="Admin Dashboards" />
    </a>
    </div>
    <!-- Sidebar brand end  -->

    <!-- User profile start -->
    <div class="sidebar-user-details">
    <div class="user-profile">
    <img src="<?php echo e(asset('admin/img/user2.png')); ?>" class="profile-thumb" alt="Admin Dashboards">
<p><?php echo e(strtoupper(session('adminData')->username)); ?></p></h6>

    <ul class="profile-actions">
    <li>
    <a href="javascript:void(0)">
    <i class="icon-gitlab"></i>
    <span class="count-label green"></span>
    </a>
    </li>
    <li>
    <a href="javascript:void(0)">
    <i class="icon-twitter1"></i>
    </a>
    </li>

    <li>

    <form action="<?php echo e(route('logout')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <button href="<?php echo e(route('logout')); ?>">
    <i class="icon-exit_to_app"></i>
    </button>
    </form>

    </li>

    </ul>
    </div>
    </div>
    <!-- User profile end -->

    <!-- Sidebar content start -->
    <div class="sidebar-content">

    <!-- sidebar menu start -->
    <div class="sidebar-menu">
    <ul>
    <li>
    <a href="index.html">
    <i class="icon-home2"></i>
    <span class="menu-text">Admin Dashboard</span>
    </a>
    </li>

    <li class="sidebar-dropdown">
    <a href="<?php echo e(route('banners.index')); ?>">
    <i class="icon-calendar1"></i>
    <span class="menu-text">Banners</span>
    </a>
    </li>

    <li class="sidebar-dropdown">
    <a href="<?php echo e(route('teams.index')); ?>">
    <i class="icon-calendar1"></i>
    <span class="menu-text">Teams</span>
    </a>
    </li>

    <li class="sidebar-dropdown">
    <a href="<?php echo e(route('best.index')); ?>">
    <i class="icon-calendar1"></i>
    <span class="menu-text">Best</span>
    </a>
    </li>


    <li class="sidebar-dropdown">
    <a href="<?php echo e(route('products.index')); ?>">
    <i class="icon-calendar1"></i>
    <span class="menu-text">Products</span>
    </a>
    </li>

    <li class="sidebar-dropdown">
    <a href="<?php echo e(route('product-images.index')); ?>">
    <i class="icon-calendar1"></i>
    <span class="menu-text">Product Images</span>
    </a>
    </li>

    <li class="sidebar-dropdown">
    <a href="<?php echo e(route('causes.index')); ?>">
    <i class="icon-calendar1"></i>
    <span class="menu-text">Causes</span>
    </a>
    </li>

    <li class="sidebar-dropdown">
    <a href="<?php echo e(route('pricings.index')); ?>">
    <i class="icon-calendar1"></i>
    <span class="menu-text">Pricings</span>
    </a>
    </li>

    <li class="sidebar-dropdown">
        <a href="<?php echo e(route('posts.index')); ?>">
        <i class="icon-calendar1"></i>
        <span class="menu-text">Posts</span>
        </a>
        </li>


        <li class="sidebar-dropdown">
            <a href="<?php echo e(route('ingredients.index')); ?>">
            <i class="icon-calendar1"></i>
            <span class="menu-text">Ingredients</span>
            </a>
            </li>

        <li class="sidebar-dropdown">
        <a href="<?php echo e(route('reviews.index')); ?>">
        <i class="icon-calendar1"></i>
        <span class="menu-text">Reviews</span>
        </a>
        </li>



    <li class="sidebar-dropdown">
    <a href="#">
    <i class="icon-unlock"></i>
    <span class="menu-text">Authentication</span>
    </a>
    <div class="sidebar-submenu">
    <ul>
        <li>
  
            </li>

    <li>
    <a href="error2.html">505</a>
    </li>
    <li>
    <a href="coming-soon.html">Coming Soon</a>
    </li>
    </ul>
    </div>
    </li>
    </ul>
    </div>
    <!-- sidebar menu end -->

    </div>
    <!-- Sidebar content end -->

    </nav>
    <!-- Sidebar wrapper end -->

    <!-- Page content start  -->
    <div class="page-content">

    <!-- Main container start -->
    <div class="main-container">

    <!-- Header start -->
    <header class="header">
    <div class="toggle-btns">
    <a id="toggle-sidebar" href="#">
    <i class="icon-list"></i>
    </a>
    <a id="pin-sidebar" href="#">
    <i class="icon-list"></i>
    </a>
    </div>
    <div class="header-items">
    <!-- Header actions start -->
    <ul class="header-actions">
    <li class="dropdown">
    <a href="#" id="notifications" data-toggle="dropdown" aria-haspopup="true">
    <i class="icon-bell"></i>
    <span class="count-label">8</span>
    </a>
    <div class="dropdown-menu dropdown-menu-right lrg" aria-labelledby="notifications">
    <div class="dropdown-menu-header">
    Notifications (40)
    </div>
    <ul class="header-notifications">
    <li>
    <a href="#">
    <div class="user-img away">
    <img src="img/user10.png" alt="Bootstrap Admin Panel">
    </div>
    <div class="details">
    <div class="user-title">Abbott</div>
    <div class="noti-details">Membership has been ended.</div>
    <div class="noti-date">Today, 07:30 pm</div>
    </div>
    </a>
    </li>
    <li>
    <a href="#">
    <div class="user-img busy">
    <img src="img/user10.png" alt="Admin Panel">
    </div>
    <div class="details">
    <div class="user-title">Braxten</div>
    <div class="noti-details">Approved new design.</div>
    <div class="noti-date">Today, 12:00 am</div>
    </div>
    </a>
    </li>
    <li>
    <a href="#">
    <div class="user-img online">
    <img src="img/user6.png" alt="Admin Template">
    </div>
    <div class="details">
    <div class="user-title">Larkyn</div>
    <div class="noti-details">Check out every table in detail.</div>
    <div class="noti-date">Today, 04:00 pm</div>
    </div>
    </a>
    </li>
    </ul>
    </div>
    </li>
    <li class="dropdown selected">
    <a href="#" id="userSettings" data-toggle="dropdown" aria-haspopup="true">
    <i class="icon-user1"></i>
    </a>
    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userSettings">
    <div class="header-profile-actions">
    <div class="header-user-profile">
    <div class="header-user">
    <img src="<?php echo e(asset('admin/img/user2.png')); ?>" alt="Admin Template">
    </div>
    <h5><?php echo e(strtoupper(session('adminData')->username)); ?></p></h5>

    <p>Super User</p>
    </div>

<a href="<?php echo e(route('change-password')); ?>" ><i class="icon-settings1"></i>Modifier Mon Compte</a>
    <a href="login.html"><i class="icon-log-out1"></i> Sign Out</a>

    <form action="<?php echo e(route('logout')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-danger">Déconnexion</button>
    </form>



    </div>
    </div>
    </li>
    <li class="balance">
    <h6>Balance</h6>
    <h3>$25,700</h3>
    </li>
    </ul>
    <!-- Header actions end -->
    </div>

    </header>
    <!-- Header end -->
    <center>
    <div class="translate-element" id="google_translate_element"></div>
    </center>

    <?php if($message = session('logsuccess')): ?>
    <center><div class="alert alert-warning alert-dismissible fade show" role="alert">
    <center> <?php echo e($message); ?></center>
    </div></center>
    <?php endif; ?>

    <!-- Page header end -->
    <?php echo $__env->yieldContent('bcontent'); ?>

    <?php echo $__env->yieldContent('content'); ?>



    </div>
    <!-- Main container end -->



    </div>
    <!-- Page content end -->

    </div>
    <!-- Page wrapper end -->
    <!--**************************
    **************************
    **************************
    Required JavaScript Files
    **************************
    **************************
    **************************-->
    <!-- Required jQuery first, then Bootstrap Bundle JS -->
    <script src="<?php echo e(asset('admin/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/moment.js')); ?>"></script>
    <!-- *************
    ************ Vendor Js Files *************
    ************* -->
    <!-- Slimscroll JS -->
    <script src="<?php echo e(asset('admin/vendor/slimscroll/slimscroll.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/vendor/slimscroll/custom-scrollbar.js')); ?>"></script>
    <?php echo $__env->yieldContent('scripts'); ?>
    <!-- Main JS -->
    <script src="<?php echo e(asset('admin/js/main.js')); ?>"></script>

    <!-- to your js part -->
<script src="script.js"></script>
<script type="text/javascript">
function googleTranslateElementInit() {
new google.translate.TranslateElement(
{pageLanguage: 'en'},
'google_translate_element'
);
} 
</script>
<script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>


    </body>
    </html><?php /**PATH C:\Users\user\Documents\laravel\dynacedrc\resources\views/admin/layouts/main.blade.php ENDPATH**/ ?>