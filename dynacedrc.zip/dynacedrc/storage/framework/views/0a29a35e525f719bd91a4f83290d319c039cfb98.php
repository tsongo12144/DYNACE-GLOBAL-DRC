        <!doctype html>
        <html lang="en">

        <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!-- Meta -->
        <meta name="description" content="Responsive Bootstrap Admin Dashboards">
        <meta name="author" content="Bootstrap Gallery">
        <link rel="shortcut icon" href="<?php echo e(asset('client/img/logo.png')); ?>" />

        <!-- Title -->
        <title>DynaceRDC</title>

        <!-- *************
        ************ Common Css Files *************
        ************ -->
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('admin/css/bootstrap.min.css')); ?>" />

        <!-- Master CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('admin/css/main.css')); ?>" />

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">

        <style>
        *{
                font-family: "Montserrat", sans-serif;
        }
        </style>

        </head>

        <body class="authentication">

        <!-- Container start -->
        <div class="container">

        <div class="row justify-content-md-center">
        <div class="col-xl-4 col-lg-5 col-md-6 col-sm-12">
        <div class="login-screen">
        <div class="login-box">
        <center>
        <h5>BIENVENU,<br />Connectez vous.</h5>

                <?php if($message = session('success')): ?>
                <center><div class="alert alert-danger alert-dismissible fade show" role="alert">
                <center> <?php echo e($message); ?></center>
                </div></center>
                <?php endif; ?>

        </center>

        <form action="<?php echo e(route('login')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="form-group">
        <input type="text"  name="username" id="username" placeholder="Nom D'utilisateur" class="form-control  <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        is-invalid   
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  />

        <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="invalid-feedback">
        <span class="text-danger"><?php echo e($message); ?></span>
        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group">
        <input type="password"  name="password" id="password" placeholder="Mot de passe" class="form-control  <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        is-invalid   
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  />
        
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="invalid-feedback">
        <span class="text-danger"><?php echo e($message); ?></span>
        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

                <div class="actions mb-4">
                <button type="submit" class="btn btn-primary">Login</button>
                </div>
        </form>
        <hr>



        </div>

    

     
        </div>
        </div>
        </div>
        </div>

        </div>
        <!-- Container end -->

        </body>

        </html><?php /**PATH C:\Users\user\Documents\laravel\dynacedrc\resources\views/admin/auth/login.blade.php ENDPATH**/ ?>