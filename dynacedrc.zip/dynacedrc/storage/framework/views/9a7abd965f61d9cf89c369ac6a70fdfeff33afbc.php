

<?php $__env->startSection('title'); ?>
dynace | galleries
<?php $__env->stopSection(); ?>

        <?php $__env->startSection('bcontent'); ?>
        <div class="container">
        <a href="<?php echo e(route('galleries.index')); ?>" class="btn btn-warning mb-2">Annuler</a>
        </div>
        <?php $__env->stopSection(); ?>

        <?php $__env->startSection('content'); ?> 
        <div class="container"> 
        <?php echo $__env->make('admin.post._form', 
        [ 'action' => route('galleries.store'),
        'method' => 'POST', 
        'buttonText' => 'Save', ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
        </div> 
        <?php $__env->stopSection(); ?>

        <?php $__env->startSection('scripts'); ?>

        <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\laravel\dynacedrc\resources\views/admin/gallery/create.blade.php ENDPATH**/ ?>