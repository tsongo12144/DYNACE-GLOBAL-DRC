<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dynace  DRC</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Rubik:wght@400;500;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
<link rel="stylesheet" href="<?php echo e(asset('client/css/stl.css')); ?>">
<link rel="shortcut icon" href="<?php echo e(asset('client/img/logo.png')); ?>" />

</head>
<body>

<header>
<!-- Your header content here -->
<div class="top-nav">
<div class="container d-flex justify-content-between align-items-center">
<div class="social-media">
<div class="social-icon"><a target="_blank" href="https://web.facebook.com/profile.php?id=61561673678061&mibextid=rS40aB7S9Ucbxw6v&_rdc=1&_rdr"><i class="fab fa-facebook-f"></i></a></div>
<div class="social-icon"><a  href="https://wa.link/tnise6" target="_blank"><i class="fab fa-whatsapp"></i></a></div>
<div class="social-icon"><a target="_blank" href="https://www.instagram.com/dynacerdc?igsh=MTlkOW4zM3h0dW0yZg%3D%3D"><i class="fab fa-instagram"></i></a></div>
<div class="social-icon"><a href="#"><i class="fab fa-twitter"></i></a></div>
<div class="social-icon"><a href="#"><i class="fab fa-linkedin-in"></i></a></div>
</div>
<div class="contact-info">
<i class="fas fa-phone-alt contact-text"> +243-997-966-712</i>
</div>
</div>
</div>

<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
    <div class="container">
    <a class="navbar-brand" href="#hero">
    <img src="<?php echo e(asset('client/img/logo.png')); ?>" alt="Logo" style="width: 90px; height: auto;">
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav ml-auto">
   <div class="translate-element" id="google_translate_element"></div>
    <li class="nav-item">
    <a class="nav-link" href="#hero">Accueill</a>
    </li>
    <li class="nav-item">
    <a class="nav-link" href="#a-propos">A Propos</a>
    </li>
    <li class="nav-item">
    <a class="nav-link" href="#notre-equipe">Equipe</a>
    </li>
    <li class="nav-item">
    <a class="nav-link" href="#nos-services">Services</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="#nos-produits">Produits</a>
        </li>

    <li class="nav-item">
    <a class="nav-link" href="#nos-realisations">Blog</a>
    </li>


    <li class="nav-item">
    <a class="btn btn-common" href="#nos-produits" >S'abonner</a>
    </li>
    </ul>
    </div>
    </div>
    </nav>

</header>



    <section class="hero" id="hero">
    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel" data-interval="4000">
    <ol class="carousel-indicators">
    <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($index); ?>" class="<?php echo e($index == 0 ? 'active' : ''); ?>"></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ol>
    <div class="carousel-inner">
    <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
    <div class="carousel-item <?php echo e($index == 0 ? 'active' : ''); ?>"> 
    <img src="<?php echo e(asset('storage/'. $banner->photo)); ?>" class="d-block w-100" style="height: 350px; object-fit: cover;" alt="<?php echo e($banner->title); ?>">
    <div class="carousel-caption d-block d-flex justify-content-center align-items-center"> 
    <h5 class="text-center glowing-text"><?php echo e($banner->title); ?></h5>
    </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
    </a>
    </div>
    </section>

    <section id="a-propos" class="a-propos">
    <div class="container">
    <h2 class="text-center section-title">A Propos</h2>
    <div class="row align-items-center">
    <div class="col-md-6">
    <div class="video-wrapper" >
    <img src="<?php echo e(asset('client/img/about.jpg')); ?>" class="img-fluid" >
    <button type="button" class="btn btn-primary video-button btn-common" data-bs-toggle="modal" data-bs-target="#exampleModal">Voir La Video</button>
    </div>
    </div>
    <div class="col-md-6">
    <div class="description">
    <p class="text">Une entreprise specialise dans les domaines du marketing reseau ,de la sante et du bien-etre a partir des supplement aimentaire de haute qualites.</p>
    <p class="text">Fondateur : HARRY TEE</p>
    <p class="text">Siège  : Malasya</p>
    <p class="text">En République Démocratique du Congo (RDC), l'entreprise <a class="dynace_link" target="_blank" href="https://www.dynaceglobal.com/index.php">
        DYNACE GLOBAL</a> est dirigée par le mentor <strong>MUHINDO DAVID</strong>, également CEO de  WOLFPACK TEAM </p>


    <button class="btn btn-primary btn-common" data-bs-toggle="collapse" data-bs-target="#moreInfo" aria-expanded="false" aria-controls="moreInfo">En savoir plus</button>
    <div class="collapse" id="moreInfo">
    <p class="addition "><a class="dynace_link" target="_blank" href="https://www.dynaceglobal.com/index.php">
    Dynace Global </a>connaît une croissance remarquable et, aujourd'hui, l'entreprise est présente dans plus de 50 pays à travers le monde, y compris la République Démocratique du Congo (RDC).</p>
    </div>
    </div>
    </div>
    </div>
    </div>
    </section>

    <section class="notre-equipe" id="notre-equipe">
    <div class="container">
    <h2 class="text-center section-title">Equipe</h2>
    <div class="row">
    <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-4">
    <div class="team-card">
    <img src="<?php echo e(asset('storage/'.$team->profile)); ?>" class="team-image"  alt="Team Member 1">
    <div class="card-content">
    <h4 class="member-name"><?php echo e($team->name); ?></h4>
    <p class="text-center">Post :<?php echo e($team->role); ?></p>
    </div>
    <div class="card-hover">
    <a href="<?php echo e(route('home.showTeam',$team)); ?>" class="btn btn-primary btn-common" >Savoir Plus</a>
    </div>
    </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    </div>
</section>


<section class="join-us">
<div class="container">
<div class="card">
<img src="<?php echo e(asset('client/img/album1.jpg')); ?>" class="card-img" alt="Join Us">
<div class="card-img-overlay d-flex flex-column justify-content-center align-items-center">
<h2 class="card-title text-white">S'abboner</h2>
<p class="card-text text-white">Rejoignez notre équipe incroyable et contribuez à notre mission.</p>
<a href="https://wa.link/tnise6" target="_blank" class="btn btn-lg btn-primary btn-common" >Devenir Membre </a>
</div>
</div>
</div>
</section>


    <section class="nos-services" id="nos-services">
    <div class="container">
    <h2 class="text-center section-title">Nos services</h2>
    <div class="row">
    <div class="col-md-4">

    <div class="service-card text-center">
    <p>📌 DÉVELOPPEMENT PERSONNEL</p>
    <button type="button" class="btn btn-primary btn-common" data-bs-toggle="offcanvas" data-bs-target="#service1Offcanvas">En savoir Plus</button>
    </div>
    </div>

    <div class="col-md-4">
    <div class="service-card text-center">
    <p>
    📌 FORMATION EN MARKETING DE RÉSEAU, SANTÉ, DÉVELOPPEMENT PERSONNELS & ENTREPRENEURIAT.
    </p>
    <button type="button" class="btn btn-primary btn-common" data-bs-toggle="offcanvas" data-bs-target="#service2Offcanvas">En savoir Plus</button>
    </div>
    </div>

    <div class="col-md-4">
    <div class="service-card text-center">
    <p>📌 FORMATION D'ENTREPRENEURIAT.
.</p>
    <button type="button" class="btn btn-primary btn-common" data-bs-toggle="offcanvas" data-bs-target="#service3Offcanvas">En savoir Plus</button>
    </div>
    </div>
    </div>
    </div>

<!-- Offcanvas for Service 1 -->
<div class="offcanvas offcanvas-start" tabindex="-1" id="service1Offcanvas" aria-labelledby="service1OffcanvasLabel">
    <div class="offcanvas-header">
        <h5 class="offcanvas-title" id="service1OffcanvasLabel">📌 DÉVELOPPEMENT PERSONNEL.</h5>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body">
        <p>Dans le développement personnel DYNACE touche à de nombreux aspects, en fonction des envies et besoins des individus :

            
                <li>
            personnel ;
                </li>
            
            <li>
            professionnel ;
            </li>
            <li>
            spirituel ;
            </li>
            <li>
            familial ;
            </li>
            <li>
                relationnel ;
            </li>
            <li>
            financier.
            </li>
        </p>
    </div>
</div>

<!-- Offcanvas for Service 2 -->
<div class="offcanvas offcanvas-start" tabindex="-1" id="service2Offcanvas" aria-labelledby="service2OffcanvasLabel">
    <div class="offcanvas-header">
        <h5 class="offcanvas-title" id="service2OffcanvasLabel">  📌 FORMATION EN MARKETING DE RÉSEAU, SANTÉ, DÉVELOPPEMENT PERSONNELS & ENTREPRENEURIAT.</h5>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body">
        <p>
            La vente multiniveau ou, selon qui l'emploie, marketing relationnel, marketing à paliers multiples, vente en réseau par cooptation, vente par réseau coopté (VRC), marketing de réseau, etc., en anglais multi-level marketing ou MLM, est une structure du réseau de vente dans laquelle les revendeurs (ou distributeurs) peuvent parrainer de nouveaux vendeurs, et être alors en partie rémunérés par une commission évaluée en pourcentage sur les ventes des recrues.    
            
        .</p>
    </div>
</div>

<!-- Offcanvas for Service 3 -->
<div class="offcanvas offcanvas-start" tabindex="-1" id="service3Offcanvas" aria-labelledby="service3OffcanvasLabel">
    <div class="offcanvas-header">
        <h5 class="offcanvas-title" id="service3OffcanvasLabel">📌 FORMATION D'ENTREPRENEURIAT.</h5>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body">
        <p>
            DYNACE GLOBAL offre Les formations professionnelles pour les  entrepreneurs.
            elles permettent d'acquérir toutes les compétences nécessaires pour devenir un bon entrepreneur et éviter les pièges de la création d'entreprise.
            Se lancer dans l’entrepreneuriat n’est pas si simple, surtout lorsque c’est votre première fois, DYNACE donne Une formation pour apprendre à être son propre patron vous permettra de profiter de l’expérience d’un entrepreneur qui a réussi.
        </p>
    </div>
</div>
</section>

<!-- Include Swiper.js -->
<link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css">

    <section class="nos-meilleur" id="nos-meilleur">
    <div class="container">
    <h2 class="text-center section-title">Nos Meilleur</h2>
    <div class="swiper-container">
    <div class="swiper-wrapper">

        <?php $__currentLoopData = $bestItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $best): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="swiper-slide">
        <div class="product-card">
        <div class="card-left">
        <img src="<?php echo e(asset('storage/'.$best->photo)); ?>" class="img-fluid" alt="Product 1">
        <div class="card-label"><?php echo e($best->status); ?></div>
        </div>
        <div class="card-right">
        <h3 style="text-transform: uppercase;"><?php echo e($best->name); ?></h3>
        <p><?php echo e($best->description); ?></p>

        </div>
        </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
    </div>
    </div>
    </section>

    <!-- Include Swiper.js -->
    <script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>


    <section class="nos-produits" id="nos-produits">
    <div class="container">
    <h2 class="text-center section-title">Nos Produits</h2>
    <div class="row">

    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-4">
        <div class="product-card">
        <div class="product-image-wrapper">
        <img src="<?php echo e(asset('storage/'.$product->cover_photo)); ?>" class="product-image img-fluid" alt="Product 2">
        <div class="card-label"><?php echo e($product->status); ?></div>
        </div>
        <div class="product-details">
        <h3 style="text-transform: uppercase"><?php echo e($product->name); ?></h3>
        <a  class="btn btn-secondary btn-common" href="<?php echo e(route('home.showProduct',$product)); ?>" >Details</a>
        </div>
        </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
    </div>
    </section>

    <section class="join-us">
    <div class="container">
    <div class="card">
    <img src="<?php echo e(asset('client/img/album1.jpg')); ?>" class="card-img" alt="Join Us">
    <div class="card-img-overlay d-flex flex-column justify-content-center align-items-center">
    <h2 class="card-title text-white">S'abonner</h2>
    <p class="card-text text-white">Rejoignez notre équipe incroyable et contribuez à notre mission.</p>
    <button class="btn btn-lg btn-primary btn-common">Devenir Membre</button>
    </div>
    </div>
    </div>
    </section>

    <section class="realisations" id="nos-realisations">
    <div class="container">
    <h2 class="text-center section-title">Realisations</h2>
    <div class="row">

    
    <?php $__currentLoopData = $reals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $real): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-4">
        <div class="post-card">
        <div class="post-image-wrapper">
        <img src="<?php echo e(asset('Storage/'.$real->image)); ?> " class="post-image img-fluid" alt="Event 1">
        <div class="event-date"><?php echo e($real->date); ?></div>
        <div class="zoom-icon">
        </div>
        </div>
        <div class="post-details">
        <p><?php echo e($real->desc1); ?>.</p>
        <button class="btn btn-primary more-info" data-bs-toggle="collapse" data-bs-target="#moreInfo4<?php echo e($real->id); ?>" aria-expanded="false" aria-controls="moreInfo<?php echo e($real->id); ?>">En savoir plus</button>
        <div class="collapse" id="moreInfo4<?php echo e($real->id); ?>">
            <div class="addition">
                <?php echo e($real->desc2); ?>

            </div>
        </div>
        </div>
        </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    

    </div>
    </div>
    </section>

    <section class="gallery" id="album">
    <div class="container">
    <h2 class="text-center section-title">Gallery</h2>
    <div class="grid">


        <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="grid-item">
            <div class="image-wrapper">
                <img src="<?php echo e(asset('storage/'.$gallery->image)); ?>" alt="<?php echo e($gallery->name); ?>" class="img-fluid">
                <div class="image-title"><?php echo e($gallery->name); ?></div>
                <div class="zoom-icon" data-bs-toggle="modal" data-bs-target="#imageModal<?php echo e($gallery->id); ?>">
                    <i class="fas fa-search-plus"></i>
                </div>
            </div>
        </div>
        
        <!-- Modal -->
        <div class="modal fade" id="imageModal<?php echo e($gallery->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel"><?php echo e($gallery->name); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
        <div class="modal-body">
        <img src="<?php echo e(asset('storage/'.$gallery->image)); ?>" alt="<?php echo e($gallery->name); ?>" class="img-fluid">
        </div>
        </div>
        </div>
        </div>
        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        

    <!-- Add more grid items as needed -->
    </div>
    </div>
    </section>
    
    <!-- Fullscreen Modal -->
    <div id="fullscreenModal" class="fullscreen-modal">
        <span class="close">&times;</span>
        <img class="modal-content" id="fullscreenImage">
        <div id="caption"></div>
    </div>

    
    <section class="pub" id="pub">
        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel" data-interval="3000">
        <ol class="carousel-indicators">
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($index); ?>" class="<?php echo e($index == 0 ? 'active' : ''); ?>"></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ol>
        <div class="carousel-inner">
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
        <div class="carousel-item <?php echo e($index == 0 ? 'active' : ''); ?>"> 
        <img src="<?php echo e(asset('Storage/'. $post->image)); ?>" class="d-block w-100" style="height: 350px; object-fit: cover;" alt="<?php echo e($post->name); ?>">
        <div class="carousel-caption d-block d-flex justify-content-center align-items-center"> 
        <h5 class="text-center glowing-text"><?php echo e($post->name); ?></h5>
        </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
        </a>
        </div>
        </section>


    

    <footer class="footer">
    <div class="container">
    <div class="row">
    <div class="col-md-3">
    <h4>A propos</h4>
    <p>Learn more about our mission, vision, and values.</p>
    </div>
    <div class="col-md-3">
    <h4>Liens </h4>
    <ul>
    <li><a href="#hero">Accueil</a></li>
    <li><a href="#a-propos">A propos</a></li>
    <li><a href="#nos-services">Nos Services</a></li>
    <li><a href="#faq">FAQ</a></li>
    </ul>
    </div>
    <div class="col-md-3">
    <h4>Contactez Nous</h4>
    <ul>
    <li><i class="fas fa-map-marker-alt"></i>Nord-Kivu Republique Democratique Du Congo Q MABANGA SUD,COMMUNE DE KARISIMBI ,Boulevard Sake No178</li>
    <li><i class="fas fa-phone"></i> (243) 997 966 712</li>
    <li><i class="fas fa-envelope"></i>  dynaceglobalcd@gmail.com</li>
    </ul>
    </div>
    <div class="col-md-3">
    <h4>Nous Suivre</h4>
    <div class="social-icons">
    <a href="https://web.facebook.com/profile.php?id=61561673678061&mibextid=rS40aB7S9Ucbxw6v&_rdc=1&_rdr" target="_blank"><i class="fab fa-facebook-f"></i></a>
    <a href="https://www.instagram.com/dynacerdc?igsh=MTlkOW4zM3h0dW0yZg%3D%3D" target="_blank"><i class="fab fa-instagram"></i></a>
    <a href="https://www.twitter.com" target="_blank"><i class="fab fa-twitter"></i></a>
    <a href="https://www.linkedin.com" target="_blank"><i class="fab fa-linkedin-in"></i></a>
    </div>
    </div>
    </div>
    <div class="row">
    <div class="col-12 text-center">
    <p>© 2K24 Designed by USENI TSONGO</p>
    </div>
    </div>
    </div>
    </footer>


<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<script src="<?php echo e(asset('client/js/script.js')); ?>"></script>

<!-- to your js part -->
<script src="script.js"></script>
<script type="text/javascript">
function googleTranslateElementInit() {
new google.translate.TranslateElement(
{pageLanguage: 'en'},
'google_translate_element'
);
} 
</script>
<script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>


</body>
</html>

<!-- WhatsApp Button -->
<a href="https://wa.link/tnise6"  class="whatsapp-button" target="_blank">
<i class='bx bxl-whatsapp'></i>
</a>

<!-- WhatsApp Button -->
<a href="https://www.instagram.com/dynacerdc?igsh=MTlkOW4zM3h0dW0yZg%3D%3D"  class="instagram-button" target="_blank">
<i class='bx bxl-instagram'></i>
</a>

<!-- WhatsApp Button -->
<a href="https://web.facebook.com/profile.php?id=61561673678061&mibextid=rS40aB7S9Ucbxw6v&_rdc=1&_rdr"  class="facebook-button" target="_blank">
<i class='bx bxl-facebook'></i>
</a>

<link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>



<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
<div class="modal-dialog modal-dialog-centered">
<div class="modal-content">
<div class="modal-header">
<h1 class="modal-title fs-5" id="exampleModalLabel"> Dynace Global DRC</h1>
<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
<div class="embed-responsive embed-responsive-16by9">
<video id="video" class="embed-responsive-item" controls>
<source src="<?php echo e(asset('admin/video/dynace.mp4')); ?>" type="video/mp4">
Your browser does not support the video tag.
</video>
</div>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-danger" data-bs-dismiss="modal">Fermer</button>
</div>
</div>
</div>
</div>


<?php /**PATH C:\Users\user\Documents\laravel\dynacedrc\resources\views/client/index.blade.php ENDPATH**/ ?>