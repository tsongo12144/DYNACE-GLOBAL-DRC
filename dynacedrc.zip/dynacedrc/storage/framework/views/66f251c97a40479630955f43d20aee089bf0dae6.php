        

        <?php $__env->startSection('title'); ?>
        dynace | realisations
        <?php $__env->stopSection(); ?>

        <?php $__env->startSection('bcontent'); ?>
        <div class="container">
        <a href="<?php echo e(route('reals.create')); ?>" class="btn btn-warning mb-2">Add</a>
        </div>
        <?php $__env->stopSection(); ?>

        <?php $__env->startSection('content'); ?>
        <!-- Row start -->

        <?php if($message = session('success')): ?>
        <center><div class="alert alert-success alert-dismissible fade show" role="alert">
        <center> <?php echo e($message); ?></center>
        </div></center>
        <?php endif; ?>

        <div class="row gutters">
        <div class="col-sm-12">

        <div class="table-container">
        <div class="t-header">
        </div>
        <div class="table-responsive">
        <table id="copy-print-csv" class="table custom-table">
        <thead>
            <tr>
            <th>Id</th>
            <th>Date</th>
            <th>Photo</th>
            <th>Actions</th>
            </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $reals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $real): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td><?php echo e($real->id); ?></td>
                    <td><?php echo e($real->date); ?></td>
                    <td><img src="<?php echo e(asset('storage/' . $real->image)); ?>" alt="Image" class="rounded-circle" width="30" height="30"></td>                
                    <td>
                    <a href="<?php echo e(route('reals.show',$real)); ?>" class="btn btn-success btn-sm">More</a>
                    <a href="<?php echo e(route('reals.edit', $real)); ?>" class="btn btn-primary btn-sm">Update</a>
                    <form action="<?php echo e(route('reals.destroy', $real->id)); ?>" method="POST" style="display:inline-block;"> 
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?> 
                    <button type="submit" class="btn btn-danger btn-sm"  onclick="return confirm('Êtes-vous sûr de vouloir supprimer ce bannière?')">Delete</button> 
                    </form>
                    </td>
                    </tr>                            
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    </table>
                    </div>
                    </div>


        </div>
        </div>
        <!-- Row end -->

        <?php $__env->stopSection(); ?>

        <?php $__env->startSection('scripts'); ?>

        <!-- Data Tables -->
        <link rel="stylesheet" href="<?php echo e(asset('admin/vendor/datatables/dataTables.bs4.css')); ?>" />
        <link rel="stylesheet" href="<?php echo e(asset('admin/vendor/datatables/dataTables.bs4-custom.css')); ?>" />
        <link href="<?php echo e(asset('admin/vendor/datatables/buttons.bs.css')); ?>" rel="stylesheet" />

        <!-- Data Tables -->
        <script src="<?php echo e(asset('admin/vendor/datatables/dataTables.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/vendor/datatables/dataTables.bootstrap.min.js')); ?>"></script>

        <!-- Custom Data tables -->
        <script src="<?php echo e(asset('admin/vendor/datatables/custom/custom-datatables.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/vendor/datatables/custom/fixedHeader.js')); ?>"></script>

        <!-- Download / CSV / Copy / Print -->
        <script src="<?php echo e(asset('admin/vendor/datatables/buttons.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/vendor/datatables/jszip.min.js')); ?>"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
        <script src="<?php echo e(asset('admin/vendor/datatables/vfs_fonts.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/vendor/datatables/html5.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/vendor/datatables/buttons.print.min.js')); ?>"></script>

        <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\laravel\dynacedrc\resources\views/admin/real/index.blade.php ENDPATH**/ ?>