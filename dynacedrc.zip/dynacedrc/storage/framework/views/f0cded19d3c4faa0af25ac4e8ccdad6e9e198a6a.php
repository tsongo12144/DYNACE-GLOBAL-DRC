

<?php $__env->startSection('title'); ?>
 dynace admin   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    		<!-- Row start -->
            <div class="row gutters">

            <div class="col-xl-3 col-sm-6 col-12">
            <div class="info-stats2">
            <div class="info-icon">
            <i class="icon-eye1"></i>
            </div>
            <div class="sale-num">
            <h2><?php echo e($banners->count()); ?></h2>
            <p>Banners</p>
            </div>
            </div>
            </div>

            <div class="col-xl-3 col-sm-6 col-12">
            <div class="info-stats2">
            <div class="info-icon">
            <i class="icon-shopping-cart1"></i>
            </div>
            <div class="sale-num">
            <h2><?php echo e($teams->count()); ?></h2>
            <p>Team Members</p>
            </div>
            </div>
            </div>

            <div class="col-xl-3 col-sm-6 col-12">
                <div class="info-stats2">
                <div class="info-icon">
                <i class="icon-exit_to_app"></i>
                </div>
                <div class="sale-num">
                <h2><?php echo e($products->count()); ?></h2>
                <p> Products</p>
                </div>
                </div>
                </div>

                <div class="col-xl-3 col-sm-6 col-12">
                <div class="info-stats2">
                <div class="info-icon">
                <i class="icon-laptop_windows"></i>
                </div>
                <div class="sale-num">
                <h2><?php echo e($reals->count()); ?></h2>
                <p>Realisations</p>
                </div>
                </div>
                </div>

                <div class="col-xl-3 col-sm-6 col-12">
                <div class="info-stats2">
                <div class="info-icon">
                <i class="icon-open_in_new"></i>
                </div>
                <div class="sale-num">
                <h2><?php echo e($posts->count()); ?></h2>
                <p>Number Of Posts</p>
                </div>
                </div>
                </div>

                <div class="col-xl-3 col-sm-6 col-12">
                    <div class="info-stats2">
                    <div class="info-icon">
                    <i class="icon-linked_camera"></i>
                    </div>
                    <div class="sale-num">
                    <h2><?php echo e($galleries->count()); ?></h2>
                    <p>Images In Gallery</p>
                    </div>
                    </div>
                    </div>

                    <div class="col-xl-3 col-sm-6 col-12">
                        <div class="info-stats2">
                        <div class="info-icon">
                        <i class="icon-sync_problem"></i>
                        </div>
                        <div class="sale-num">
                        <h2><?php echo e($bests->count()); ?></h2>
                        <p>Best Product</p>
                        </div>
                        </div>
                        </div>

                        <div class="col-xl-3 col-sm-6 col-12">
                            <div class="info-stats2">
                            <div class="info-icon">
                            <i class="icon-message-circle"></i>
                            </div>
                            <div class="sale-num">
                            <h2><?php echo e($members->count()); ?></h2>
                            <p>Members</p>
                            </div>
                            </div>
                            </div>

            </div>
            <!-- Row end -->

            					<!-- Row start -->
					<div class="row gutters">

						<div class="col-xl-4 col-sm-12 col-12">
							<div class="card">
								<div class="card-header">
									<div class="card-title">Tasks</div>
								</div>
								<div class="card-body pt-0">
									<div id="radialTasks"></div>
									<ul class="task-list-container">
										<li class="task-list-item primary">
											<div class="task-icon">
												<i class="icon-clipboard"></i>
											</div>
											<div class="task-info">
												<h6 class="task-title">New</h6>
												<p class="amount-spend">12</p>
											</div>
										</li>
										<li class="task-list-item secondary">
											<div class="task-icon">
												<i class="icon-clipboard"></i>
											</div>
											<div class="task-info">
												<h6 class="task-title">Done</h6>
												<p class="amount-spend">15</p>
											</div>
										</li>
									</ul>
								</div>
							</div>
						</div>

                        <div class="col-xl-4 col-sm-12 col-12">
							<div class="card">
								<div class="card-header">
									<div class="card-title">Tasks</div>
								</div>
								<div class="card-body pt-0">
									<div id="radialTasks"></div>
									<ul class="task-list-container">
										<li class="task-list-item primary">
											<div class="task-icon">
												<i class="icon-clipboard"></i>
											</div>
											<div class="task-info">
												<h6 class="task-title">New</h6>
												<p class="amount-spend">12</p>
											</div>
										</li>
										<li class="task-list-item secondary">
											<div class="task-icon">
												<i class="icon-clipboard"></i>
											</div>
											<div class="task-info">
												<h6 class="task-title">Done</h6>
												<p class="amount-spend">15</p>
											</div>
										</li>
									</ul>
								</div>
							</div>
						</div>

                        <div class="col-xl-4 col-sm-12 col-12">
							<div class="card">
								<div class="card-header">
									<div class="card-title">Tasks</div>
								</div>
								<div class="card-body pt-0">
									<div id="radialTasks"></div>
									<ul class="task-list-container">
										<li class="task-list-item primary">
											<div class="task-icon">
												<i class="icon-clipboard"></i>
											</div>
											<div class="task-info">
												<h6 class="task-title">New</h6>
												<p class="amount-spend">12</p>
											</div>
										</li>
										<li class="task-list-item secondary">
											<div class="task-icon">
												<i class="icon-clipboard"></i>
											</div>
											<div class="task-info">
												<h6 class="task-title">Done</h6>
												<p class="amount-spend">15</p>
											</div>
										</li>
									</ul>
								</div>
							</div>
						</div>

					</div>
					<!-- Row end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\laravel\dynacedrc\resources\views/admin/index.blade.php ENDPATH**/ ?>