<!DOCTYPE html>
<html>
<head>
    <title>Welcome to Dynace Global DRC</title>
</head>
<body>
    <h1>Welcome, {{ $first_name }} {{ $last_name }}!</h1>
    <p>We are thrilled to have you join us at Dynace Global DRC. You will be contacted soon for more information.</p>
    <a href="{{ $website }}" style="display: inline-block; padding: 10px 20px; color: #fff; background-color: #007bff; text-decoration: none; border-radius: 5px;">Visit our Website</a>
</body>
</html>
