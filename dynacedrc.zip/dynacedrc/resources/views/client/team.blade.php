<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dynace  DRC | {{$team->name}}</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Rubik:wght@400;500;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
<link rel="stylesheet" href="{{asset('client/css/stl.css')}}">
<link rel="shortcut icon" href="{{asset('client/img/logo.png')}}" />

</head>
<body>

<header>
<!-- Your header content here -->
<div class="top-nav">
<div class="container d-flex justify-content-between align-items-center">
<div class="social-media">
<div class="social-icon"><a target="_blank" href="https://web.facebook.com/profile.php?id=61561673678061&mibextid=rS40aB7S9Ucbxw6v&_rdc=1&_rdr"><i class="fab fa-facebook-f"></i></a></div>
<div class="social-icon"><a  href="https://wa.link/tnise6" target="_blank"><i class="fab fa-whatsapp"></i></a></div>
<div class="social-icon"><a target="_blank" href="https://www.instagram.com/dynacerdc?igsh=MTlkOW4zM3h0dW0yZg%3D%3D"><i class="fab fa-instagram"></i></a></div>
<div class="social-icon"><a href="#"><i class="fab fa-twitter"></i></a></div>
<div class="social-icon"><a href="#"><i class="fab fa-linkedin-in"></i></a></div>
</div>
<div class="contact-info">
<i class="fas fa-phone-alt contact-text"> +243-997-966-712</i>
</div>
</div>
</div>

<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
    <div class="container">
    <a class="navbar-brand" href="{{route('client')}}">
    <img src="{{asset('client/img/logo.png')}}" alt="Logo" style="width: 90px; height: auto;">
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav ml-auto">
   <div class="translate-element" id="google_translate_element"></div>
    <li class="nav-item">
    <a class="nav-link" href="#hero">Accueill</a>
    </li>
    <li class="nav-item">
    <a class="nav-link" href="#a-propos">A Propos</a>
    </li>
    </ul>
    </div>
    </div>
    </nav>

</header>

<section class="hero" id="hero">
    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel" data-interval="3000">
    <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    </ol>

    <div class="carousel-inner">
    <div class="carousel-item active">
    <img src="{{asset('storage/'.$team->team_picture)}}" class="d-block w-100" alt="...">
    <div class="carousel-caption d-block">
    <h5>{{$team->team_name}}</h5>
    </div>
    </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
    </a>
    </div>
    </section>

   

    <section id="a-propos" class="a-propos">
    <div class="container">
    <h2 class="text-center section-title">{{$team->name}}</h2>
    <p class="text-center post-title">{{$team->role}}</p>
    <div class="row align-items-center">
    <div class="col-md-6">
    <div class="video-wrapper" >
    <img src="{{asset('storage/'.$team->profile)}}" class="img-fluid" >
    <button type="button" class="btn btn-primary video-button btn-common" 
    data-bs-toggle="modal" data-bs-target="#exampleModal">Voir La Video</button>
    </div>
    </div>
    <div class="col-md-6">
    <div class="description">
    <p class="text">{{$team->description}}</p>
     <p class="text">{{$team->description_add}}</p>

    </div>
    </div>
    </div>
    </div>
    </section>

   

<section class="join-us">
<div class="container">
<div class="card">
<img src="{{asset('storage/'.$team->team_picture)}}" class="card-img" alt="Join Us">
<div class="card-img-overlay d-flex flex-column justify-content-center align-items-center">
<h2 class="card-title text-white">S'abboner</h2>
<p class="card-text text-white">Rejoignez notre équipe incroyable et contribuez à notre mission.</p>
<a href="https://wa.link/tnise6" target="_blank" class="btn btn-lg btn-primary btn-common" >Devenir Membre </a>
</div>
</div>
</div>
</section>


    <section class="map-location" id="map-location">
    <div class="container">
    <h2 class="text-center">notre localisation</h2>
    <div class="map-embed">
    <iframe 
    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3916.8247049703034!2d30.061944815260577!3d-1.9440953985799415!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x19dca6b30b0d7c4b%3A0xa7715e716a1f7b3c!2sKigali%2C%20Rwanda!5e0!3m2!1sen!2s!4v1679961679893!5m2!1sen!2s" 
    width="600" 
    height="450" 
    style="border:0;" 
    allowfullscreen="" 
    loading="lazy" 
    referrerpolicy="no-referrer-when-downgrade">
    </iframe>
    </div>
    </div>
    </section>

    


    <footer class="footer">
    <div class="container">
    <div class="row">
    <div class="col-md-3">
    <h4>A propos</h4>
    <p>Learn more about our mission, vision, and values.</p>
    </div>
    <div class="col-md-3">
    <h4>Liens </h4>
    <ul>
    <li><a href="#hero">Accueil</a></li>
    <li><a href="#a-propos">A propos</a></li>
    <li><a href="#nos-services">Nos Services</a></li>
    <li><a href="#faq">FAQ</a></li>
    </ul>
    </div>
    <div class="col-md-3">
    <h4>Contactez Nous</h4>
    <ul>
    <li><i class="fas fa-map-marker-alt"></i>Nord-Kivu Republique Democratique Du Congo Q MABANGA SUD,COMMUNE DE KARISIMBI ,Boulevard Sake No178</li>
    <li><i class="fas fa-phone"></i> (243) 997 966 712</li>
    <li><i class="fas fa-envelope"></i>  dynaceglobalcd@gmail.com</li>
    </ul>
    </div>
    <div class="col-md-3">
    <h4>Nous Suivre</h4>
    <div class="social-icons">
    <a href="https://web.facebook.com/profile.php?id=61561673678061&mibextid=rS40aB7S9Ucbxw6v&_rdc=1&_rdr" target="_blank"><i class="fab fa-facebook-f"></i></a>
    <a href="https://www.instagram.com/dynacerdc?igsh=MTlkOW4zM3h0dW0yZg%3D%3D" target="_blank"><i class="fab fa-instagram"></i></a>
    <a href="https://www.twitter.com" target="_blank"><i class="fab fa-twitter"></i></a>
    <a href="https://www.linkedin.com" target="_blank"><i class="fab fa-linkedin-in"></i></a>
    </div>
    </div>
    </div>
    <div class="row">
    <div class="col-12 text-center">
    <p>© 2K24 Designed by USENI TSONGO</p>
    </div>
    </div>
    </div>
    </footer>


<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<script src="{{asset('client/js/script.js')}}"></script>

<!-- to your js part -->
<script src="script.js"></script>
<script type="text/javascript">
function googleTranslateElementInit() {
new google.translate.TranslateElement(
{pageLanguage: 'en'},
'google_translate_element'
);
} 
</script>
<script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>


</body>
</html>

<!-- WhatsApp Button -->
<a href="https://wa.link/tnise6"  class="whatsapp-button" target="_blank">
<i class='bx bxl-whatsapp'></i>
</a>

<link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>



<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
<div class="modal-dialog modal-dialog-centered">
<div class="modal-content">
<div class="modal-header">
<h1 class="modal-title fs-5" id="exampleModalLabel"> Dynace Global DRC</h1>
<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
<div class="embed-responsive embed-responsive-16by9">
<video id="video" class="embed-responsive-item" controls>
<source src="files/videos/dynace.mp4" type="video/mp4">
Your browser does not support the video tag.
</video>
</div>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-danger" data-bs-dismiss="modal">Fermer</button>
</div>
</div>
</div>
</div>


