		@extends('admin.layouts.main')

		@section('title')
		best | sow
		@endsection

		@section('content') 
		<!-- Row start -->
		<div class="row gutters">
		<div class="col-sm-12">
		<div class="card">
		<div class="card-body">

		<!-- Row start -->
		<div class="row gutters">
		<div class="col-lg-4 col-sm-6 col-12">
		<div class="form-group">
		<label class="label">Image</label>
		<div class="custom-date-input">
		<img src="{{ asset('storage/' . $best->photo) }}" alt="Image" class="" width="150" height="100">
		</div>
		</div>
		</div>
		<div class="col-lg-4 col-sm-6 col-12">
		<div class="form-group">
		<label class="label">Name :</label>
		<div class="custom-date-input">
		<h4>{{ $best->name }}</h4>
		</div>
		</div>
		</div>

		<div class="col-lg-4 col-sm-6 col-12">
		<div class="form-group">
		<label class="label">Statut</label>
		<div class="custom-date-input">
		<h4>{{ $best->status }}</h4>
		</div>
		</div>
		</div>

	<div class="col-lg-4 col-sm-6 col-12">
	<div class="form-group">
	<label class="label">Description</label>
	<div class="custom-date-input">
	<h4>{{ $best->description }}</h4>
	</div>
	</div>
	</div>



		<div class="col-lg-4 col-sm-6 col-12">
		<div class="form-group">
		<label class="label">Created</label>
		<div class="custom-date-input">
		<h4>{{ $best->created_at }}</h4>
		</div>
		</div>
		</div>
		<div class="col-lg-4 col-sm-6 col-12">
		<div class="form-group">
		<label class="label">Updated</label>
		<div class="custom-date-input">
		<h4>{{ $best->updated_at }}</h4>

		</div>
		</div>
		</div>


		</div>
		<!-- Row end -->
		<a href="{{route('best.edit',$best)}}" class="btn btn-info mb-2">Modifier</a>
		<a href="{{route('best.index')}}" class="btn btn-secondary mb-2">Retour</a>
		</div>
		</div>
		</div>
		</div>
		<!-- Row end -->
		@endsection

		@section('scripts')

		@endsection