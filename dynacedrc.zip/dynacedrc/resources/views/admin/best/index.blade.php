        @extends('admin.layouts.main')

        @section('title')
       dynace | best
        @endsection

        @section('bcontent')
        <div class="container">
        <a href="{{route('best.create')}}" class="btn btn-warning mb-2">Add</a>
        </div>
        @endsection

        @section('content')
        <!-- Row start -->

        @if($message = session('success'))
        <center><div class="alert alert-success alert-dismissible fade show" role="alert">
        <center> {{$message}}</center>
        </div></center>
        @endif

        <div class="row gutters">
        <div class="col-sm-12">

        <div class="table-container">
        <div class="t-header">
        </div>
        <div class="table-responsive">
        <table id="copy-print-csv" class="table custom-table">
        <thead>
            <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Photo</th>
            <th>Status</th>
            <th>Actions</th>
            </tr>
            </thead>
            <tbody>
              @foreach ($bests as $best )
                    <tr>
                    <td>{{$best->id}}</td>
                    <td>{{$best->name}}</td>
                    <td><img src="{{ asset('storage/' . $best->photo) }}" alt="Image" class="rounded-circle" width="30" height="30"></td>                
                    <td>{{$best->status}}</td>
                    <td>
                    <a href="{{route('best.show',$best)}}" class="btn btn-success btn-sm">More</a>
                    <a href="{{ route('best.edit', $best) }}" class="btn btn-primary btn-sm">Update</a>
                    <form action="{{ route('best.destroy', $best->id) }}" method="POST" style="display:inline-block;"> 
                    @csrf
                    @method('DELETE') 
                    <button type="submit" class="btn btn-danger btn-sm"  onclick="return confirm('Êtes-vous sûr de vouloir supprimer ce bannière?')">Delete</button> 
                    </form>
                    </td>
                    </tr>                            
                    @endforeach
                    </tbody>
                    </table>
                    </div>
                    </div>


        </div>
        </div>
        <!-- Row end -->

        @endsection

        @section('scripts')

        <!-- Data Tables -->
        <link rel="stylesheet" href="{{asset('admin/vendor/datatables/dataTables.bs4.css')}}" />
        <link rel="stylesheet" href="{{asset('admin/vendor/datatables/dataTables.bs4-custom.css')}}" />
        <link href="{{asset('admin/vendor/datatables/buttons.bs.css')}}" rel="stylesheet" />

        <!-- Data Tables -->
        <script src="{{asset('admin/vendor/datatables/dataTables.min.js')}}"></script>
        <script src="{{asset('admin/vendor/datatables/dataTables.bootstrap.min.js')}}"></script>

        <!-- Custom Data tables -->
        <script src="{{asset('admin/vendor/datatables/custom/custom-datatables.js')}}"></script>
        <script src="{{asset('admin/vendor/datatables/custom/fixedHeader.js')}}"></script>

        <!-- Download / CSV / Copy / Print -->
        <script src="{{asset('admin/vendor/datatables/buttons.min.js')}}"></script>
        <script src="{{asset('admin/vendor/datatables/jszip.min.js')}}"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
        <script src="{{asset('admin/vendor/datatables/vfs_fonts.js')}}"></script>
        <script src="{{asset('admin/vendor/datatables/html5.min.js')}}"></script>
        <script src="{{asset('admin/vendor/datatables/buttons.print.min.js')}}"></script>

        @endsection