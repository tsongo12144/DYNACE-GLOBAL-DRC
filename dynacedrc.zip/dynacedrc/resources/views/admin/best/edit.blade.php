        @extends('admin.layouts.main')

        @section('title')
        best | edit
        @endsection

        @section('bcontent')
        <div class="container">
        <a href="{{route('best.index')}}" class="btn btn-warning mb-2">Back</a>
        </div>
        @endsection

        @section('content')
        <div class="container"> 
        @include('admin.best._form', 
        [ 'action' => route('best.update', $best->id), 
        'method' => 'PUT', 
        'best' => $best, 
        'buttonText' => 'Update', ]) 
        </div>
        @endsection

        @section('scripts')

        @endsection