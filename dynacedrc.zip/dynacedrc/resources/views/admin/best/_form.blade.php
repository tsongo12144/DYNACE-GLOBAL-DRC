<form action="{{ $action}}" method="POST" enctype="multipart/form-data">
              @csrf
              @if ($method === 'PUT') 
              @method('PUT') 
              @endif


            <!-- Row start -->
            <div class="row gutters">

            <div class="col-sm-12">
            <div class="card">
            <div class="card-body">

            <div class="row gutters">
            <div class="col-sm-4 col-12">
            <div class="form-group">
            <label for="inputName">Name</label>
            <input type="text" name="name"  id="name" value="{{old('name',$best->name ?? '')}}" placeholder="Entrez Le Nom"
            class="form-control @error('name') is-invalid @else is-valid @enderror"  >
            @error('name')
            <div class="invalid-feedback">
            {{ $message }}
            </div>
            @enderror          
            </div>
            </div>


            <div class="col-sm-4 col-12">
            <div class="form-group">
            <label for="inputName">Photo</label>
            <input type="file" name="photo"  id="photo"  accept="image/*" 
            class="form-control @error('photo') is-invalid @else is-valid @enderror"  >
            @if (isset($best) && $best->photo) 
            <img src="{{ asset('storage/' . $best->photo) }}" alt="photo" width="100" class="mt-2"> 
            @endif
            @error('photo')
            <div class="invalid-feedback">
            {{ $message }}
            </div>
            @enderror          
            </div>
            </div>

            <div class="col-sm-4 col-12">
            <div class="form-group">
            <label for="inputName">Status</label>
            <select name="status" id="status" class="form-control is-valid @error('status') is-invalid @enderror">
            <option value="in stock" {{ (old('status') ?? $best->status ?? '') === 'in stock' ? 'selected' : '' }}>in stock</option> 
            <option value="out of stock" {{ (old('status') ?? $best->status ?? '') === 'out of stock' ? 'selected' : '' }}>out of stock</option>
            </select>                       
            @error('status')
            <div class="invalid-feedback">
            {{ $message }}
            </div>
            @enderror          
            </div>
            </div>


<div class="col-sm-4 col-12">
<div class="form-group">
<label for="inputName">Description</label>
<textarea  rows="10" cols="10"   id="description" name="description" class="form-control @error('description') is-invalid @else is-valid @enderror">
{{ old('description', $best->description ?? '') }}
</textarea> 
@error('description')
<div class="invalid-feedback">
{{ $message }}
</div>
@enderror          
</div>
</div>
              

            </div>
            <button type="submit" class="btn btn-primary mb-2">{{ $buttonText }}</button>
            </div>
              </div>
              </div>
              </div>
              <!-- Row end -->
</form>