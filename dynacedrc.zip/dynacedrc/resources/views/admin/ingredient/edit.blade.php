        @extends('admin.layouts.main')

        @section('title')
       dynace| ingredients
        @endsection

        @section('bcontent')
        <div class="container">
        <a href="{{route('ingredients.index')}}" class="btn btn-warning mb-2">Retour</a>
        </div>
        @endsection

        @section('content')
        <div class="container"> 
        @include('admin.ingredient._form',
        [ 'action' => route('ingredients.update', $ingredient->id), 
        'method' => 'PUT', 
        'ingredient' => $ingredient, 
        'buttonText' => 'Update', ]) 
        </div>
        @endsection

        @section('scripts')

        @endsection