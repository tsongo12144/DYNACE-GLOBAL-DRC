@extends('admin.layouts.main')

@section('title')
dynace | ingredient
@endsection

        @section('bcontent')
        <div class="container">
        <a href="{{route('ingredients.index')}}" class="btn btn-warning mb-2">Back</a>
        </div>
        @endsection

        @section('content') 
        <div class="container"> 
        @include('admin.ingredient._form', 
        [ 'action' => route('ingredients.store'),
        'method' => 'POST', 
        'buttonText' => 'Save', ]) 
        </div> 
        @endsection

        @section('scripts')

        @endsection