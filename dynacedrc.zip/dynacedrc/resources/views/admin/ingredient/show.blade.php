		@extends('admin.layouts.main')

		@section('title')
		ingredient | show
		@endsection

		@section('content') 
		<!-- Row start -->
		<div class="row gutters">
		<div class="col-sm-12">
		<div class="card">
		<div class="card-body">

		<!-- Row start -->
		<div class="row gutters">
		<div class="col-lg-4 col-sm-6 col-12">
		<div class="form-group">
		<label class="label">Image</label>
		<div class="custom-date-input">
		<img src="{{ asset('storage/' . $ingredient->image) }}" alt="Image" class="" width="150" height="100">
		</div>
		</div>
		</div>

		<div class="col-lg-4 col-sm-6 col-12">
		<div class="form-group">
		<label class="label">Product :</label>
		<div class="custom-date-input">
		<h4>{{ $ingredient->product->name }}</h4>
		</div>
		</div>
		</div>

		<div class="col-lg-4 col-sm-6 col-12">
			<div class="form-group">
			<label class="label">Name :</label>
			<div class="custom-date-input">
			<h4>{{ $ingredient->name }}</h4>
			</div>
			</div>
			</div>

			<div class="col-lg-4 col-sm-6 col-12">
				<div class="form-group">
				<label class="label">Description :</label>
				<div class="custom-date-input">
				<h4>{{ $ingredient->description }}</h4>
				</div>
				</div>
				</div>

		<div class="col-lg-4 col-sm-6 col-12">
		<div class="form-group">
		<label class="label">Created</label>
		<div class="custom-date-input">
		<h4>{{ $ingredient->created_at }}</h4>
		</div>
		</div>
		</div>

		<div class="col-lg-4 col-sm-6 col-12">
		<div class="form-group">
		<label class="label">Updated</label>
		<div class="custom-date-input">
		<h4>{{ $ingredient->updated_at }}</h4>

		</div>
		</div>
		</div>


		</div>
		<!-- Row end -->
		<a href="{{route('ingredients.edit',$ingredient)}}" class="btn btn-info mb-2">Update</a>
		<a href="{{route('ingredients.index')}}" class="btn btn-secondary mb-2">Back</a>
		</div>
		</div>
		</div>
		</div>
		<!-- Row end -->
		@endsection

		@section('scripts')

		@endsection