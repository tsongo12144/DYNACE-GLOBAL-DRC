<form action="{{ $action}}" method="POST" enctype="multipart/form-data">
              @csrf
              @if ($method === 'PUT') 
              @method('PUT') 
              @endif


            <!-- Row start -->
            <div class="row gutters">

            <div class="col-sm-12">
            <div class="card">
            <div class="card-body">

            <div class="row gutters">
            <div class="col-sm-4 col-12">
            <div class="form-group">
            <label for="inputName">Name</label>
            <input type="text" name="name"  id="name" value="{{old('name',$product->name ?? '')}}" placeholder="Entrez Le Nom Du Produit"
            class="form-control @error('name') is-invalid @else is-valid @enderror"  >
            @error('name')
            <div class="invalid-feedback">
            {{ $message }}
            </div>
            @enderror          
            </div>
            </div>

            <div class="col-sm-4 col-12">
            <div class="form-group">
            <label for="inputName">Photo</label>
            <input type="file" name="cover_photo"  id="cover_photo"  accept="image/*" 
            class="form-control @error('cover_photo') is-invalid @else is-valid @enderror"  >
            @if (isset($product) && $product->cover_photo) 
            <img src="{{ asset('storage/' . $product->cover_photo) }}" alt="cover_photo" width="100" class="mt-2"> 
            @endif
            @error('cover_photo')
            <div class="invalid-feedback">
            {{ $message }}
            </div>
            @enderror          
            </div>
            </div>

            <div class="col-sm-4 col-12">
            <div class="form-group">
            <label for="inputName">Status</label>
            <select name="status" id="status" class="form-control is-valid @error('status') is-invalid @enderror">
            <option value="actif" {{ (old('status') ?? $product->status ?? '') === 'active' ? 'selected' : '' }}>Actif</option> 
            <option value="inactif" {{ (old('status') ?? $product->status ?? '') === 'inactive' ? 'selected' : '' }}>Inactif</option>
            </select>                       
            @error('status')
            <div class="invalid-feedback">
            {{ $message }}
            </div>
            @enderror          
            </div>
            </div>


            <div class="col-sm-4 col-12">
              <div class="form-group">
              <label for="inputName">Description</label>
              <textarea  rows="10" cols="10"   id="description" name="description" class="form-control @error('description') is-invalid @else is-valid @enderror">
                {{ old('description', $product->description ?? '') }}
              </textarea> 
              @error('description')
              <div class="invalid-feedback">
              {{ $message }}
              </div>
              @enderror          
              </div>
              </div>

              <div class="col-sm-4 col-12">
                <div class="form-group">
                <label for="inputName">Prescription</label>
                <textarea  rows="10" cols="10"   id="prescription" name="prescription" class="form-control @error('prescription') is-invalid @else is-valid @enderror">
                  {{ old('prescription', $product->prescription ?? '') }}
                </textarea> 
                @error('prescription')
                <div class="invalid-feedback">
                {{ $message }}
                </div>
                @enderror          
                </div>
                </div>

            </div>
            <button type="submit" class="btn btn-primary mb-2">{{ $buttonText }}</button>
            </div>
              </div>
              </div>
              </div>
              <!-- Row end -->
</form>