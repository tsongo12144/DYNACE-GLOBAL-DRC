@extends('admin.layouts.main')

@section('title')
product|create
@endsection

        @section('bcontent')
        <div class="container">
        <a href="{{route('products.index')}}" class="btn btn-warning mb-2">Back</a>
        </div>
        @endsection

        @section('content') 
        <div class="container"> 
        @include('admin.product._form', 
        [ 'action' => route('products.store'),
        'method' => 'POST', 
        'buttonText' => 'Save', ]) 
        </div> 
        @endsection

        @section('scripts')

        @endsection