        @extends('admin.layouts.main')

        @section('title')
        dynace | product
        @endsection

        @section('bcontent')
        <div class="container">
        <a href="{{route('products.index')}}" class="btn btn-warning mb-2">Back</a>
        </div>
        @endsection

        @section('content')
        <div class="container"> 
        @include('admin.product._form', 
        [ 'action' => route('products.update', $product->id), 
        'method' => 'PUT', 
        'product' => $product, 
        'buttonText' => 'Update', ]) 
        </div>
        @endsection

        @section('scripts')

        @endsection