		@extends('admin.layouts.main')

		@section('title')
		product | sow
		@endsection

		@section('content') 
		<!-- Row start -->
		<div class="row gutters">
		<div class="col-sm-12">
		<div class="card">
		<div class="card-body">

		<!-- Row start -->
		<div class="row gutters">
		<div class="col-lg-4 col-sm-6 col-12">
		<div class="form-group">
		<label class="label">Image</label>
		<div class="custom-date-input">
		<img src="{{ asset('storage/' . $product->cover_photo) }}" alt="Image" class="" width="150" height="100">
		</div>
		</div>
		</div>
		<div class="col-lg-4 col-sm-6 col-12">
		<div class="form-group">
		<label class="label">Name :</label>
		<div class="custom-date-input">
		<h4>{{ $product->name }}</h4>
		</div>
		</div>
		</div>

		<div class="col-lg-4 col-sm-6 col-12">
		<div class="form-group">
		<label class="label">Statut</label>
		<div class="custom-date-input">
		<h4>{{ $product->status }}</h4>
		</div>
		</div>
		</div>

		<div class="col-lg-4 col-sm-6 col-12">
			<div class="form-group">
			<label class="label">Description</label>
			<div class="custom-date-input">
			<h4>{{ $product->description }}</h4>
			</div>
			</div>
			</div>

			<div class="col-lg-4 col-sm-6 col-12">
				<div class="form-group">
				<label class="label">prescription</label>
				<div class="custom-date-input">
				<h4>{{ $product->prescription }}</h4>
				</div>
				</div>
				</div>

		<div class="col-lg-4 col-sm-6 col-12">
		<div class="form-group">
		<label class="label">Created</label>
		<div class="custom-date-input">
		<h4>{{ $product->created_at }}</h4>
		</div>
		</div>
		</div>
		<div class="col-lg-4 col-sm-6 col-12">
		<div class="form-group">
		<label class="label">Updated</label>
		<div class="custom-date-input">
		<h4>{{ $product->updated_at }}</h4>

		</div>
		</div>
		</div>


		</div>
		<!-- Row end -->
		<a href="{{route('products.edit',$product)}}" class="btn btn-info mb-2">Update</a>
		<a href="{{route('products.index')}}" class="btn btn-secondary mb-2">Back</a>
		</div>
		</div>
		</div>
		</div>
		<!-- Row end -->
		@endsection

		@section('scripts')

		@endsection