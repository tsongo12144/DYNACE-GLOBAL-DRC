<form action="{{ $action}}" method="POST" enctype="multipart/form-data">
              @csrf
              @if ($method === 'PUT') 
              @method('PUT') 
              @endif

            <!-- Row start -->
            <div class="row gutters">

            <div class="col-sm-12">
            <div class="card">
            <div class="card-body">

            <div class="row gutters">

            <div class="col-sm-4 col-12">
            <div class="form-group">
            <label for="inputName">Product</label>
            <select name="product_id" id="product_id" class="form-control is-valid @error('product_id') is-invalid @enderror">
            @foreach ($products as $id => $name)
            <option value="{{ $id }}" {{ isset($review) && $review->product_id == $id ? 'selected' : '' }}></option>                 
            @endforeach
            </select>                       
            @error('product_id')
            <div class="invalid-feedback">
            {{ $message }}
            </div>
            @enderror          
            </div>
            </div>

                  <div class="col-sm-4 col-12">
                  <div class="form-group">
                  <label for="inputName">ClientName</label>
                  <input type="text" name="name"  id="name" value="{{old('name',$review->name ?? '')}}" placeholder="Entrez Le Nom"
                  class="form-control @error('name') is-invalid @else is-valid @enderror"  >
                  @error('name')
                  <div class="invalid-feedback">
                  {{ $message }}
                  </div>
                  @enderror          
                  </div>
                  </div>


                <div class="col-sm-4 col-12">
                  <div class="form-group">
                  <label for="inputName">Message</label>
                  <textarea  rows="10" cols="10"   id="message" name="message" class="form-control @error('message') is-invalid @else is-valid @enderror">
                    {{ old('message', $review->message ?? '') }}
                  </textarea> 
                  @error('message')
                  <div class="invalid-feedback">
                  {{ $message }}
                  </div>
                  @enderror          
                  </div>
                  </div>



            </div>
            <button type="submit" class="btn btn-primary mb-2">{{ $buttonText }}</button>
            </div>
              </div>
              </div>
              </div>
              <!-- Row end -->
</form>