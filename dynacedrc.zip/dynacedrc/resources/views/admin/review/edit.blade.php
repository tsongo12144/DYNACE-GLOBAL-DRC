        @extends('admin.layouts.main')

        @section('title')
       dynace| reviews
        @endsection

        @section('bcontent')
        <div class="container">
        <a href="{{route('reviews.index')}}" class="btn btn-warning mb-2">Retour</a>
        </div>
        @endsection

        @section('content')
        <div class="container"> 
        @include('admin.review._form', 
        [ 'action' => route('reviews.update', $review->id), 
        'method' => 'PUT', 
        'review' => $review, 
        'buttonText' => 'Update', ]) 
        </div>
        @endsection

        @section('scripts')

        @endsection