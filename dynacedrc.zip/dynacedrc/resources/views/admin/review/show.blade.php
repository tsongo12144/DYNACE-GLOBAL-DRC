		@extends('admin.layouts.main')

		@section('title')
		product | review
		@endsection

		@section('content') 
		<!-- Row start -->
		<div class="row gutters">
		<div class="col-sm-12">
		<div class="card">
		<div class="card-body">

		<!-- Row start -->
		<div class="row gutters">

		<div class="col-lg-4 col-sm-6 col-12">
		<div class="form-group">
		<label class="label">Name :</label>
		<div class="custom-date-input">
		<h4>{{ $review->product->name }}</h4>
		</div>
		</div>
		</div>

		<div class="col-lg-4 col-sm-6 col-12">
		<div class="form-group">
		<label class="label">User</label>
		<div class="custom-date-input">
		<h4>{{ $review->name }}</h4>
		</div>
		</div>
		</div>

		<div class="col-lg-4 col-sm-6 col-12">
		<div class="form-group">
		<label class="label">Message</label>
		<div class="custom-date-input">
		<h4>{{ $review->message }}</h4>
		</div>
		</div>
		</div>

		<div class="col-lg-4 col-sm-6 col-12">
		<div class="form-group">
		<label class="label">Created</label>
		<div class="custom-date-input">
		<h4>{{ $review->created_at }}</h4>
		</div>
		</div>
		</div>

		<div class="col-lg-4 col-sm-6 col-12">
		<div class="form-group">
		<label class="label">Updated</label>
		<div class="custom-date-input">
		<h4>{{ $review->updated_at }}</h4>

		</div>
		</div>
		</div>


		</div>
		<!-- Row end -->
		<a href="{{route('reviews.edit',$review)}}" class="btn btn-info mb-2">Update</a>
		<a href="{{route('reviews.index')}}" class="btn btn-secondary mb-2">Back</a>
		</div>
		</div>
		</div>
		</div>
		<!-- Row end -->
		@endsection

		@section('scripts')

		@endsection