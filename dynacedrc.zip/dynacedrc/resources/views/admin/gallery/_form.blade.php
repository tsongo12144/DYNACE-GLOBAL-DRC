<form action="{{ $action}}" method="POST" enctype="multipart/form-data">
              @csrf
              @if ($method === 'PUT') 
              @method('PUT') 
              @endif


            <!-- Row start -->
            <div class="row gutters">

            <div class="col-sm-12">
            <div class="card">
            <div class="card-body">

            <div class="row gutters">
            <div class="col-sm-4 col-12">
            <div class="form-group">
            <label for="inputName">Name</label>
            <input type="text" name="name"  id="name" value="{{old('name',$gallery->name ?? '')}}" placeholder="Entrez Le Nom"
            class="form-control @error('name') is-invalid @else is-valid @enderror"  >
            @error('name')
            <div class="invalid-feedback">
            {{ $message }}
            </div>
            @enderror          
            </div>
            </div>

            <div class="col-sm-4 col-12">
            <div class="form-group">
            <label for="inputName">Photo</label>
            <input type="file" name="image"  id="image"  accept="image/*" 
            class="form-control @error('image') is-invalid @else is-valid @enderror"  >
            @if (isset($gallery) && $gallery->image) 
            <img src="{{ asset('storage/' . $gallery->image) }}" alt="image" width="100" class="mt-2"> 
            @endif
            @error('image')
            <div class="invalid-feedback">
            {{ $message }}
            </div>
            @enderror          
            </div>
            </div>

            </div>
            <button type="submit" class="btn btn-primary mb-2">{{ $buttonText }}</button>
            </div>
              </div>
              </div>
              </div>
              <!-- Row end -->
</form>