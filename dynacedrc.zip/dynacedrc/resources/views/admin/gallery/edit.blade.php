        @extends('admin.layouts.main')

        @section('title')
        dynace | gallery
        @endsection

        @section('bcontent')
        <div class="container">
        <a href="{{route('galleries.index')}}" class="btn btn-warning mb-2">Back</a>
        </div>
        @endsection

        @section('content')
        <div class="container"> 
        @include('admin.gallery._form', 
        [ 'action' => route('galleries.update', $gallery->id), 
        'method' => 'PUT', 
        'gallery' => $gallery, 
        'buttonText' => 'Update', ]) 
        </div>
        @endsection

        @section('scripts')

        @endsection