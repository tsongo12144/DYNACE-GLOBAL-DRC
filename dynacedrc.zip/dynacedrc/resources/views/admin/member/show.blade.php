		@extends('admin.layouts.main')

		@section('title')
		members | show
		@endsection

		@section('content') 
		<!-- Row start -->
		<div class="row gutters">
		<div class="col-sm-12">
		<div class="card">
		<div class="card-body">

		<!-- Row start -->
		<div class="row gutters">


		<div class="col-lg-4 col-sm-6 col-12">
		<div class="form-group">
		<label class="label">NumbeOf :</label>
		<div class="custom-date-input">
		<h4>{{ $member->first_name }}</h4>
		</div>
		</div>
		</div>

		<div class="col-lg-4 col-sm-6 col-12">
		<div class="form-group">
		<label class="label">NumbeOf :</label>
		<div class="custom-date-input">
		<h4>{{ $member->last_name }}</h4>
		</div>
		</div>
		</div>


		<div class="col-lg-4 col-sm-6 col-12">
		<div class="form-group">
		<label class="label">Price</label>
		<div class="custom-date-input">
		<h4>{{ $member->phone }}</h4>
		</div>
		</div>
		</div>

		<div class="col-lg-4 col-sm-6 col-12">
		<div class="form-group">
		<label class="label">Updated</label>
		<div class="custom-date-input">
		<h4>{{ $member->created_at }}</h4>

		</div>
		</div>
		</div>

		<div class="col-lg-4 col-sm-6 col-12">
			<div class="form-group">
			<label class="label">Updated</label>
			<div class="custom-date-input">
			<h4>{{ $member->updated_at }}</h4>
	
			</div>
			</div>
			</div>


		</div>
		<!-- Row end -->
		<a href="{{route('members.edit',$member)}}" class="btn btn-info mb-2">Update</a>
		<a href="{{route('members.index')}}" class="btn btn-secondary mb-2">Back</a>
		</div>
		</div>
		</div>
		</div>
		<!-- Row end -->
		@endsection

		@section('scripts')

		@endsection