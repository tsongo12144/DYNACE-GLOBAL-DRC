<form action="{{ $action}}" method="POST" enctype="multipart/form-data">
@csrf
@if ($method === 'PUT') 
@method('PUT') 
@endif

<!-- Row start -->
<div class="row gutters">

<div class="col-sm-12">
<div class="card">
<div class="card-body">

<div class="row gutters">

<div class="col-sm-4 col-12">
  <div class="form-group">
  <label for="inputName">First Name</label>
  <input type="text" name="first_name"  id="first_name" value="{{old('first_name',$member->first_name ?? '')}}" placeholder="Entrez Le Nom"
  class="form-control @error('first_name') is-invalid @else is-valid @enderror"  >
  @error('first_name')
  <div class="invalid-feedback">
  {{ $message }}
  </div>
  @enderror          
  </div>
  </div>

  <div class="col-sm-4 col-12">
    <div class="form-group">
    <label for="inputName">Last Name</label>
    <input type="text" name="last_name"  id="last_name" value="{{old('last_name',$member->last_name ?? '')}}" placeholder="Entrez Le Nom"
    class="form-control @error('last_name') is-invalid @else is-valid @enderror"  >
    @error('last_name')
    <div class="invalid-feedback">
    {{ $message }}
    </div>
    @enderror          
    </div>
    </div>

  <div class="col-sm-4 col-12">
    <div class="form-group">
    <label for="inputName">Phone</label>
    <input type="text" name="phone"  id="phone" value="{{old('phone',$member->phone ?? '')}}" placeholder="+250 784555256"
    class="form-control @error('phone') is-invalid @else is-valid @enderror"  >
    @error('phone')
    <div class="invalid-feedback">
    {{ $message }}
    </div>
    @enderror          
    </div>
    </div>

  <div class="col-sm-4 col-12">
  <div class="form-group">
  <label for="inputName">Email</label>
  <input type="email" name="email"  id="email" value="{{old('email',$member->email ?? '')}}" placeholder="tsongosantoss@gmail.com"
  class="form-control @error('email') is-invalid @else is-valid @enderror"  >
  @error('email')
  <div class="invalid-feedback">
  {{ $message }}
  </div>
  @enderror          
  </div>
  </div>







</div>
<button type="submit" class="btn btn-primary mb-2">{{ $buttonText }}</button>
</div>
</div>
</div>
</div>
<!-- Row end -->
</form>