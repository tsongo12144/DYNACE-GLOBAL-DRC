        @extends('admin.layouts.main')

        @section('title')
       dynace| members
        @endsection

        @section('bcontent')
        <div class="container">
        <a href="{{route('members.index')}}" class="btn btn-warning mb-2">Back</a>
        </div>
        @endsection

        @section('content')
        <div class="container"> 
        @include('admin.member._form', 
        [ 'action' => route('members.update', $member->id), 
        'method' => 'PUT', 
        'member' => $member, 
        'buttonText' => 'Update', ]) 
        </div>
        @endsection

        @section('scripts')

        @endsection