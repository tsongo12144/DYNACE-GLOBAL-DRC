        @extends('admin.layouts.main')

        @section('title')
       dynace| productImage
        @endsection

        @section('bcontent')
        <div class="container">
        <a href="{{route('recommendations.index')}}" class="btn btn-warning mb-2">Retour</a>
        </div>
        @endsection

        @section('content')
        <div class="container"> 
        @include('admin.reco._form', 
        [ 'action' => route('recommendations.update', $recommendation->id), 
        'method' => 'PUT', 
        'recommendation' => $recommendation, 
        'buttonText' => 'Update', ]) 
        </div>
        @endsection

        @section('scripts')

        @endsection