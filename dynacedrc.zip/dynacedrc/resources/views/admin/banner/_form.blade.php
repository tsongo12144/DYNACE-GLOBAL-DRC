<form action="{{ $action}}" method="POST" enctype="multipart/form-data">
              @csrf
              @if ($method === 'PUT') 
              @method('PUT') 
              @endif


            <!-- Row start -->
            <div class="row gutters">

            <div class="col-sm-12">
            <div class="card">
            <div class="card-body">

            <div class="row gutters">
            <div class="col-sm-4 col-12">
            <div class="form-group">
            <label for="inputName">Title</label>
            <input type="text" name="title"  id="title" value="{{old('title',$banner->title ?? '')}}" placeholder="Entrez Le Titre"
            class="form-control @error('title') is-invalid @else is-valid @enderror"  >
            @error('title')
            <div class="invalid-feedback">
            {{ $message }}
            </div>
            @enderror          
            </div>
            </div>

            <div class="col-sm-4 col-12">
            <div class="form-group">
            <label for="inputName">Photo</label>
            <input type="file" name="photo"  id="photo"  accept="image/*" 
            class="form-control @error('photo') is-invalid @else is-valid @enderror"  >
            @if (isset($banner) && $banner->photo) 
            <img src="{{ asset('storage/' . $banner->photo) }}" alt="photo" width="100" class="mt-2"> 
            @endif
            @error('photo')
            <div class="invalid-feedback">
            {{ $message }}
            </div>
            @enderror          
            </div>
            </div>

            <div class="col-sm-4 col-12">
            <div class="form-group">
            <label for="inputName">Status</label>
            <select name="status" id="status" class="form-control is-valid @error('status') is-invalid @enderror">
            <option value="actif" {{ (old('status') ?? $banner->status ?? '') === 'active' ? 'selected' : '' }}>Actif</option> 
            <option value="inactif" {{ (old('status') ?? $banner->status ?? '') === 'inactive' ? 'selected' : '' }}>Inactif</option>
            </select>                       
            @error('status')
            <div class="invalid-feedback">
            {{ $message }}
            </div>
            @enderror          
            </div>
            </div>
            </div>
            <button type="submit" class="btn btn-primary mb-2">{{ $buttonText }}</button>
            </div>
              </div>
              </div>
              </div>
              <!-- Row end -->
</form>