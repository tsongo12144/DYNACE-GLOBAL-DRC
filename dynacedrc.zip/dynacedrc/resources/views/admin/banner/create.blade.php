@extends('admin.layouts.main')

@section('title')
banner
@endsection

        @section('bcontent')
        <div class="container">
        <a href="{{route('banners.index')}}" class="btn btn-warning mb-2">Annuler</a>
        </div>
        @endsection

        @section('content') 
        <div class="container"> 
        @include('admin.banner._form', 
        [ 'action' => route('banners.store'),
        'method' => 'POST', 
        'buttonText' => 'Save', ]) 
        </div> 
        @endsection

        @section('scripts')

        @endsection