@extends('admin.layouts.main')

@section('title')
dynace | product
@endsection

        @section('bcontent')
        <div class="container">
        <a href="{{route('product-images.index')}}" class="btn btn-warning mb-2">Back</a>
        </div>
        @endsection

        @section('content') 
        <div class="container"> 
        @include('admin.productImage._form', 
        [ 'action' => route('product-images.store'),
        'method' => 'POST', 
        'buttonText' => 'Save', ]) 
        </div> 
        @endsection

        @section('scripts')

        @endsection