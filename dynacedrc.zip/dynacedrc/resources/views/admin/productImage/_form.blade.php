<form action="{{ $action}}" method="POST" enctype="multipart/form-data">
              @csrf
              @if ($method === 'PUT') 
              @method('PUT') 
              @endif

            <!-- Row start -->
            <div class="row gutters">

            <div class="col-sm-12">
            <div class="card">
            <div class="card-body">

            <div class="row gutters">

              <div class="col-sm-4 col-12">
                <div class="form-group">
                <label for="inputName">Product</label>
                <select name="product_id" id="product_id" class="form-control is-valid @error('product_id') is-invalid @enderror">
                  @foreach ($products as $id => $name)
                  <option value="{{ $id }}" {{ isset($productImage) && $productImage->product_id == $id ? 'selected' : '' }}> {{ $name }} </option>                 
                  @endforeach
                </select>                       
                @error('product_id')
                <div class="invalid-feedback">
                {{ $message }}
                </div>
                @enderror          
                </div>
                </div>

            <div class="col-sm-4 col-12">
            <div class="form-group">
            <label for="inputName">Photo</label>
            <input type="file" name="image"  id="image"  accept="image/*" 
            class="form-control @error('image') is-invalid @else is-valid @enderror"  >
            @if (isset($productImage) && $productImage->image) 
            <img src="{{ asset('storage/' . $productImage->image) }}" alt="image" width="100" class="mt-2"> 
            @endif
            @error('image')
            <div class="invalid-feedback">
            {{ $message }}
            </div>
            @enderror          
            </div>
            </div>



            </div>
            <button type="submit" class="btn btn-primary mb-2">{{ $buttonText }}</button>
            </div>
              </div>
              </div>
              </div>
              <!-- Row end -->
</form>