		@extends('admin.layouts.main')

		@section('title')
		product | show
		@endsection

		@section('content') 
		<!-- Row start -->
		<div class="row gutters">
		<div class="col-sm-12">
		<div class="card">
		<div class="card-body">

		<!-- Row start -->
		<div class="row gutters">
		<div class="col-lg-4 col-sm-6 col-12">
		<div class="form-group">
		<label class="label">Image</label>
		<div class="custom-date-input">
		<img src="{{ asset('storage/' . $productImage->image) }}" alt="Image" class="" width="150" height="100">
		</div>
		</div>
		</div>
		<div class="col-lg-4 col-sm-6 col-12">
		<div class="form-group">
		<label class="label">Name :</label>
		<div class="custom-date-input">
		<h4>{{ $productImage->product->name }}</h4>
		</div>
		</div>
		</div>

		<div class="col-lg-4 col-sm-6 col-12">
		<div class="form-group">
		<label class="label">Created</label>
		<div class="custom-date-input">
		<h4>{{ $productImage->created_at }}</h4>
		</div>
		</div>
		</div>

		<div class="col-lg-4 col-sm-6 col-12">
		<div class="form-group">
		<label class="label">Updated</label>
		<div class="custom-date-input">
		<h4>{{ $productImage->updated_at }}</h4>

		</div>
		</div>
		</div>


		</div>
		<!-- Row end -->
		<a href="{{route('product-images.edit',$productImage)}}" class="btn btn-info mb-2">Update</a>
		<a href="{{route('product-images.index')}}" class="btn btn-secondary mb-2">Back</a>
		</div>
		</div>
		</div>
		</div>
		<!-- Row end -->
		@endsection

		@section('scripts')

		@endsection