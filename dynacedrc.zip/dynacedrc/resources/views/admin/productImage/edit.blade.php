        @extends('admin.layouts.main')

        @section('title')
       dynace| productImage
        @endsection

        @section('bcontent')
        <div class="container">
        <a href="{{route('product-images.index')}}" class="btn btn-warning mb-2">Retour</a>
        </div>
        @endsection

        @section('content')
        <div class="container"> 
        @include('admin.productImage._form', 
        [ 'action' => route('product-images.update', $productImage->id), 
        'method' => 'PUT', 
        'productImage' => $productImage, 
        'buttonText' => 'Update', ]) 
        </div>
        @endsection

        @section('scripts')

        @endsection