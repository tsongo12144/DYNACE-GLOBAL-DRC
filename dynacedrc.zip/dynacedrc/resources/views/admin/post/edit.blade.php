        @extends('admin.layouts.main')

        @section('title')
        dynace | post
        @endsection

        @section('bcontent')
        <div class="container">
        <a href="{{route('posts.index')}}" class="btn btn-warning mb-2">Retour</a>
        </div>
        @endsection

        @section('content')
        <div class="container"> 
        @include('admin.post._form', 
        [ 'action' => route('posts.update', $post->id), 
        'method' => 'PUT', 
        'post' => $post, 
        'buttonText' => 'Update', ]) 
        </div>
        @endsection

        @section('scripts')

        @endsection