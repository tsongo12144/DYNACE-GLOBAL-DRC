<form action="{{ $action}}" method="POST" enctype="multipart/form-data">
              @csrf
              @if ($method === 'PUT') 
              @method('PUT') 
              @endif


            <!-- Row start -->
            <div class="row gutters">

            <div class="col-sm-12">
            <div class="card">
            <div class="card-body">

            <div class="row gutters">
            <div class="col-sm-4 col-12">
            <div class="form-group">
            <label for="inputName">Name</label>
            <input type="text" name="name"  id="name" value="{{old('name',$team->name ?? '')}}" placeholder="Entrez Le Nom"
            class="form-control @error('name') is-invalid @else is-valid @enderror"  >
            @error('name')
            <div class="invalid-feedback">
            {{ $message }}
            </div>
            @enderror          
            </div>
            </div>

            <div class="col-sm-4 col-12">
            <div class="form-group">
            <label for="inputName">Profile</label>
            <input type="file" name="profile"  id="profile"  accept="image/*" 
            class="form-control @error('profile') is-invalid @else is-valid @enderror"  >
            @if (isset($team) && $team->profile) 
            <img src="{{ asset('storage/' . $team->profile) }}" alt="profile" width="100" class="mt-2"> 
            @endif
            @error('profile')
            <div class="invalid-feedback">
            {{ $message }}
            </div>
            @enderror          
            </div>
            </div>

            <div class="col-sm-4 col-12">
              <div class="form-group">
              <label for="inputName">Team Picture</label>
              <input type="file" name="team_picture"  id="team_picture"  accept="image/*" 
              class="form-control @error('team_picture') is-invalid @else is-valid @enderror"  >
              @if (isset($team) && $team->team_picture) 
              <img src="{{ asset('storage/' . $team->team_picture) }}" alt="team_picture" width="100" class="mt-2"> 
              @endif
              @error('team_picture')
              <div class="invalid-feedback">
              {{ $message }}
              </div>
              @enderror          
              </div>
              </div>

              <div class="col-sm-4 col-12">
                <div class="form-group">
                <label for="inputName">Posts</label>
                <input type="text" name="role"  id="role" value="{{old('role',$team->role ?? '')}}" placeholder="Entrez Le Nom"
                class="form-control @error('role') is-invalid @else is-valid @enderror"  >
                @error('role')
                <div class="invalid-feedback">
                {{ $message }}
                </div>
                @enderror          
                </div>
                </div>

                <div class="col-sm-8 col-12">
                  <div class="form-group">
                  <label for="inputName">Leader</label>
                  <input type="text" name="team_name"  id="team_name" value="{{old('team_name',$team->team_name ?? '')}}" placeholder="Entrez Le Nom"
                  class="form-control @error('team_name') is-invalid @else is-valid @enderror"  >
                  @error('team_name')
                  <div class="invalid-feedback">
                  {{ $message }}
                  </div>
                  @enderror          
                  </div>
                  </div> 

                <div class="col-sm-4 col-12">
                <div class="form-group">
                <label for="inputName">Description</label>
                <textarea  rows="10" cols="10"   id="description" name="description" class="form-control @error('description') is-invalid @else is-valid @enderror">
                  {{ old('description', $team->description ?? '') }}
                </textarea> 
                @error('description')
                <div class="invalid-feedback">
                {{ $message }}
                </div>
                @enderror          
                </div>
                </div>
                
                <div class="col-sm-4 col-12">
                  <div class="form-group">
                  <label for="inputName">Description</label>
                  <textarea  rows="10" cols="10"   id="description_add" name="description_add" class="form-control @error('description_add') is-invalid @else is-valid @enderror">
                    {{ old('description_add', $team->description_add ?? '') }}
                  </textarea> 
                  @error('description_add')
                  <div class="invalid-feedback">
                  {{ $message }}
                  </div>
                  @enderror          
                  </div>
                  </div>
            </div>
            <button type="submit" class="btn btn-primary mb-2">{{ $buttonText }}</button>
            </div>
              </div>
              </div>
              </div>
              <!-- Row end -->
</form>