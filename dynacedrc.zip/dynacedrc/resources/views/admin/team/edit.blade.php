        @extends('admin.layouts.main')

        @section('title')
        dynace| team
        @endsection

        @section('bcontent')
        <div class="container">
        <a href="{{route('teams.index')}}" class="btn btn-secondary mb-2">Back</a>
        </div>
        @endsection

        @section('content')
        <div class="container"> 
        @include('admin.team._form', 
        [ 'action' => route('teams.update', $team->id), 
        'method' => 'PUT', 
        'team' => $team, 
        'buttonText' => 'Update', ]) 
        </div>
        @endsection

        @section('scripts')

        @endsection