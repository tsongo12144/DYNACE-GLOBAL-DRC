		@extends('admin.layouts.main')

		@section('title')
		team | sow
		@endsection

		@section('content') 
		<!-- Row start -->
		<div class="row gutters">
		<div class="col-sm-12">
		<div class="card">
		<div class="card-body">

		<!-- Row start -->
		<div class="row gutters">
		<div class="col-lg-4 col-sm-6 col-12">
		<div class="form-group">
		<label class="label">Leader</label>
		<div class="custom-date-input">
		<img src="{{ asset('storage/' . $team->profile) }}" alt="Image" class="" style="conte-fit:cover" width="150" height="200">
		</div>
		</div>
		</div>

		<div class="col-lg-4 col-sm-6 col-12">
		<div class="form-group">
		<label class="label">Nom :</label>
		<div class="custom-date-input">
		<h4>{{ $team->name }}</h4>
		</div>
		</div>
		</div>

		<div class="col-lg-4 col-sm-6 col-12">
			<div class="form-group">
			<label class="label">Leader</label>
			<div class="custom-date-input">
			<img src="{{ asset('storage/' . $team->team_picture) }}" alt="Image" class="" style="conte-fit:cover" width="250" height="150">
			</div>
			</div>
			</div>

		<div class="col-lg-4 col-sm-6 col-12">
		<div class="form-group">
		<label class="label">Team Name</label>
		<div class="custom-date-input">
		<h4>{{ $team->team_name }}</h4>
		</div>
		</div>
		</div>

		<div class="col-lg-4 col-sm-6 col-12">
		<div class="form-group">
		<label class="label">Post</label>
		<div class="custom-date-input">
		<h4>{{ $team->role }}</h4>
		</div>
		</div>
		</div>

		<div class="col-lg-4 col-sm-6 col-12">
			<div class="form-group">
			<label class="label">Description</label>
			<div class="custom-date-input">
			<h4>{{ $team->description }}</h4>
			</div>
			</div>
			</div>

			<div class="col-lg-4 col-sm-6 col-12">
				<div class="form-group">
				<label class="label">Description Add</label>
				<div class="custom-date-input">
				<h4>{{ $team->description_add }}</h4>
				</div>
				</div>
				</div>

			</div>
			<!-- Row end -->
			<a href="{{route('teams.edit',$team)}}" class="btn btn-info mb-2">Update</a>
			<a href="{{route('teams.index')}}" class="btn btn-secondary mb-2">Back</a>
			</div>
			</div>
			</div>
			</div>
			<!-- Row end -->
			@endsection

			@section('scripts')

			@endsection