		@extends('admin.layouts.main')

		@section('title')
		causes | show
		@endsection

		@section('content') 
		<!-- Row start -->
		<div class="row gutters">
		<div class="col-sm-12">
		<div class="card">
		<div class="card-body">

		<!-- Row start -->
		<div class="row gutters">

		<div class="col-lg-4 col-sm-6 col-12">
		<div class="form-group">
		<label class="label">Name :</label>
		<div class="custom-date-input">
		<h4>{{ $cause->product->name }}</h4>
		</div>
		</div>
		</div>

		<div class="col-lg-4 col-sm-6 col-12">
			<div class="form-group">
			<label class="label">Name :</label>
			<div class="custom-date-input">
			<h4>{{ $cause->name }}</h4>
			</div>
			</div>
			</div>

		<div class="col-lg-4 col-sm-6 col-12">
		<div class="form-group">
		<label class="label">Description</label>
		<div class="custom-date-input">
		<h4>{{ $cause->description }}</h4>
		</div>
		</div>
		</div>

		<div class="col-lg-4 col-sm-6 col-12">
		<div class="form-group">
		<label class="label">Updated</label>
		<div class="custom-date-input">
		<h4>{{ $cause->created_at }}</h4>

		</div>
		</div>
		</div>

		<div class="col-lg-4 col-sm-6 col-12">
			<div class="form-group">
			<label class="label">Updated</label>
			<div class="custom-date-input">
			<h4>{{ $cause->updated_at }}</h4>
	
			</div>
			</div>
			</div>


		</div>
		<!-- Row end -->
		<a href="{{route('causes.edit',$cause)}}" class="btn btn-info mb-2">Update</a>
		<a href="{{route('causes.index')}}" class="btn btn-secondary mb-2">Back</a>
		</div>
		</div>
		</div>
		</div>
		<!-- Row end -->
		@endsection

		@section('scripts')

		@endsection