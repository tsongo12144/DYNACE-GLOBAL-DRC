        @extends('admin.layouts.main')

        @section('title')
       dynace| cause
        @endsection

        @section('bcontent')
        <div class="container">
        <a href="{{route('causes.index')}}" class="btn btn-warning mb-2">Retour</a>
        </div>
        @endsection

        @section('content')
        <div class="container"> 
        @include('admin.cause._form', 
        [ 'action' => route('causes.update', $cause->id), 
        'method' => 'PUT', 
        'cause' => $cause, 
        'buttonText' => 'Update', ]) 
        </div>
        @endsection

        @section('scripts')

        @endsection