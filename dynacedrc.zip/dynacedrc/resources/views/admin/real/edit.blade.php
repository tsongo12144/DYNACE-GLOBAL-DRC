        @extends('admin.layouts.main')

        @section('title')
       dynace| realisations
        @endsection

        @section('bcontent')
        <div class="container">
        <a href="{{route('reals.index')}}" class="btn btn-warning mb-2">Retour</a>
        </div>
        @endsection

        @section('content')
        <div class="container"> 
        @include('admin.real._form',
        [ 'action' => route('reals.update', $real->id), 
        'method' => 'PUT', 
        'real' => $real, 
        'buttonText' => 'Update', ]) 
        </div>
        @endsection

        @section('scripts')

        @endsection