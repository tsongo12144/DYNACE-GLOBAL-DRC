<form action="{{ $action}}" method="POST" enctype="multipart/form-data">
              @csrf
              @if ($method === 'PUT') 
              @method('PUT') 
              @endif

            <!-- Row start -->
            <div class="row gutters">

            <div class="col-sm-12">
            <div class="card">
            <div class="card-body">

            <div class="row gutters">


          <div class="col-sm-4 col-12">
            <div class="form-group">
            <label for="inputName">Date</label>
            <input type="date" name="date"  id="date" value="{{old('date',$real->date ?? '')}}" placeholder="Entrez Le Nom"
            class="form-control @error('date') is-invalid @else is-valid @enderror"  >
            @error('date')
            <div class="invalid-feedback">
            {{ $message }}
            </div>
            @enderror          
            </div>
            </div>

            

            <div class="col-sm-4 col-12">
              <div class="form-group">
              <label for="inputName">Photo</label>
              <input type="file" name="image"  id="image"  accept="image/*" 
              class="form-control @error('image') is-invalid @else is-valid @enderror"  >
              @if (isset($real) && $real->image) 
              <img src="{{ asset('storage/' . $real->image) }}" alt="image" width="100" class="mt-2"> 
              @endif
              @error('image')
              <div class="invalid-feedback">
              {{ $message }}
              </div>
              @enderror          
              </div>
              </div>

            <div class="col-sm-4 col-12">
              <div class="form-group">
              <label for="inputName">Description 1</label>
              <textarea  rows="10" cols="10"   id="desc1" name="desc1" class="form-control @error('desc1') is-invalid @else is-valid @enderror">
                {{ old('desc1', $real->desc1 ?? '') }}
              </textarea> 
              @error('description')
              <div class="invalid-feedback">
              {{ $message }}
              </div>
              @enderror          
              </div>
              </div>

              <div class="col-sm-4 col-12">
                <div class="form-group">
                <label for="inputName">Description 2</label>
                <textarea  rows="10" cols="10"   id="desc2" name="desc2" class="form-control @error('desc2') is-invalid @else is-valid @enderror">
                  {{ old('desc2', $real->desc2 ?? '') }}
                </textarea> 
                @error('description')
                <div class="invalid-feedback">
                {{ $message }}
                </div>
                @enderror          
                </div>
                </div>




            </div>
            <button type="submit" class="btn btn-primary mb-2">{{ $buttonText }}</button>
            </div>
              </div>
              </div>
              </div>
              <!-- Row end -->
</form>