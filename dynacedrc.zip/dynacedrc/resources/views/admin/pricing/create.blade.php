@extends('admin.layouts.main')

@section('title')
dynace | pricing
@endsection

        @section('bcontent')
        <div class="container">
        <a href="{{route('pricings.index')}}" class="btn btn-warning mb-2">Back</a>
        </div>
        @endsection

        @section('content') 
        <div class="container"> 
        @include('admin.pricing._form', 
        [ 'action' => route('pricings.store'),
        'method' => 'POST', 
        'buttonText' => 'Save', ]) 
        </div> 
        @endsection

        @section('scripts')

        @endsection