<form action="{{ $action}}" method="POST" enctype="multipart/form-data">
@csrf
@if ($method === 'PUT') 
@method('PUT') 
@endif

<!-- Row start -->
<div class="row gutters">

<div class="col-sm-12">
<div class="card">
<div class="card-body">

<div class="row gutters">

<div class="col-sm-4 col-12">
<div class="form-group">
<label for="inputName">Product</label>
<select name="product_id" id="product_id" class="form-control is-valid @error('product_id') is-invalid @enderror">
@foreach ($products as $id => $name)
<option value="{{ $id }}" {{ isset($pricing) && $pricing->product_id == $id ? 'selected' : '' }}> {{ $name }} </option>                 
@endforeach
</select>                       
@error('product_id')
<div class="invalid-feedback">
{{ $message }}
</div>
@enderror          
</div>
</div>



<div class="col-sm-4 col-12">
  <div class="form-group">
  <label for="inputName">NumberOf</label>
  <input type="text" name="number"  id="number" value="{{old('number',$pricing->number ?? '')}}" placeholder="Entrez Le Nombre"
  class="form-control @error('number') is-invalid @else is-valid @enderror"  >
  @error('number')
  <div class="invalid-feedback">
  {{ $message }}
  </div>
  @enderror          
  </div>
  </div>

  <div class="col-sm-4 col-12">
    <div class="form-group">
    <label for="inputName">Price</label>
    <input type="number" name="price"  id="price" value="{{old('price',$pricing->price ?? '')}}" placeholder="Entrez Le Nombre"
    class="form-control @error('price') is-invalid @else is-valid @enderror"  >
    @error('price')
    <div class="invalid-feedback">
    {{ $message }}
    </div>
    @enderror          
    </div>
    </div>







</div>
<button type="submit" class="btn btn-primary mb-2">{{ $buttonText }}</button>
</div>
</div>
</div>
</div>
<!-- Row end -->
</form>