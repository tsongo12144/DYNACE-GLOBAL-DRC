<!doctype html>
<html lang="en">

<head>
<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<!-- Meta -->
<meta name="description" content="Responsive Bootstrap Admin Dashboards">
<meta name="author" content="Bootstrap Gallery">
<link rel="shortcut icon" href="{{asset('client/img/logo.png')}}" />

<!-- Title -->
<title>DynaceRDC</title>

<!-- *************
************ Common Css Files *************
************ -->
<!-- Bootstrap CSS -->
<link rel="stylesheet" href="{{asset('admin/css/bootstrap.min.css')}}" />

<!-- Master CSS -->
<link rel="stylesheet" href="{{asset('admin/css/main.css')}}" />

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">

<style>
*{
        font-family: "Montserrat", sans-serif;
}
</style>

</head>

<body class="authentication">

<!-- Container start -->
<div class="container">

<div class="row justify-content-md-center">
<div class="col-xl-4 col-lg-5 col-md-6 col-sm-12">
<div class="login-screen">
<div class="login-box">
<center>
<h5>MODIFIER LE COMPTE.</h5>

        @if($message = session('success'))
        <center><div class="alert alert-danger alert-dismissible fade show" role="alert">
        <center> {{$message}}</center>
        </div></center>
        @endif

</center>

<form action="{{route('change-password')}}" method="POST">
@csrf

<div class="form-group">
<input type="text"  name="username" id="username" placeholder="Nom D'utilisateur" value="{{ session('adminData')->username }}"
 class="form-control  @error('username')
is-invalid   
@enderror"  />

@error('username')
<div class="invalid-feedback">
<span class="text-danger">{{ $message }}</span>
</div>
@enderror
</div>

<div class="form-group">
        <input type="password"  name="old_password" id="old_password" placeholder="Encien Mot de Passe" class="form-control  @error('old_password')
        is-invalid   
        @enderror"  />

        @error('old_password')
        <div class="invalid-feedback">
        <span class="text-danger">{{ $message }}</span>
        </div>
        @enderror
        </div>

    <div class="form-group">
    <input type="password"  name="new_password" id="new_password" placeholder="Nouveau Mot de Passe" class="form-control  @error('new_password')
    is-invalid   
    @enderror"  />
    @error('new_password')
    <div class="invalid-feedback">
    <span class="text-danger">{{ $message }}</span>
    </div>
    @enderror
    </div>


    <div class="form-group">
        <input type="password"  name="new_password_confirmation" id="new_password_confirmation" placeholder="Confirmer Nouveau Mot de Passe" class="form-control  @error('new_password_confirmation')
        is-invalid   
        @enderror"  />
    
        @error('new_password_confirmation')
        <div class="invalid-feedback">
        <span class="text-danger">{{ $message }}</span>
        </div>
        @enderror
        </div>
    

        <div class="actions mb-4">
        <button type="submit" class="btn btn-primary">Modifier</button>
        <a href="{{route('backSide')}}" class="btn btn-secondary" >Annuler</a>
        </div>
</form>
<hr>



</div>




</div>
</div>
</div>
</div>

</div>
<!-- Container end -->

</body>

</html>